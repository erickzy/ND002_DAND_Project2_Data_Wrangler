
# 项目描述
**你的目标：**
清洗 WeRateDogs 推特数据，创建有趣可靠的分析和可视化。推特档案很大，但是只包括基本的推特信息。对 "Wow!" 进行收集、评估和清洗，是分析和可视化应该做的。

**你在这个项目中的任务如下：**
* 清洗数据包括：
    * 收集数据
    * 评估数据
    * 清洗数据
* 对清洗过的数据进行储存、分析和可视化
* 汇报 1) 你的数据清洗过程 和 2) 你的数据分析和可视化

# 项目目的

## Uda目标

### 收集数据
* 学员能够从各种来源和文件格式中收集数据
    - （DONE）在“项目详细信息”页面上使用至少三（3）个不同来源。
    - （DONE）在“项目详细信息”页面上，使用至少三（3）种不同的文件格式。首先将每一条数据导入到一个单独的 pandas 数据框中。

### 评估数据
* 学员能够以可视化和编程方式评估数据的质量和整洁度。
    - （DONE）可视化评估：每张收集的数据都显示在 Jupyter Notebook 中，以便进行可视化评估。 一旦显示出来，数据可以在外部应用程序（如 Excel，文本编辑器）中进行评估。
    - （DONE）编程评估：使用 pandas 的功能和/或方法来评估数据。
* 学员能够彻底对数据集进行评估
    - （DONE）学员能够检测到至少 八（8）个数据质量问题和两（2）个整洁度问题，包括待清理问题以满足项目要求。每一个问题用一到几句话记录下来。

### 清理数据
* 学员根据数据清理过程中的步骤来逐步完成他们的清理工作
    - （DONE）清理过程中的定义，编码和测试步骤都有明确的记录。
* 学员能够使用编程方式彻底清理数据集
    - （DONE）在清理之前，保存原始数据的副本。
    - （DONE）评估阶段确定的所有问题都可以通过 Python 和 pandas 成功清理，并包括满足项目要求所需的清理任务。
    - （DONE）学员需要创建一个整洁的主数据集（或者多个数据集，如果有必要的话）与所有收集的数据片段。

### 存储并处理清洁过的数据
* 学员能够存储已经收集、评估并清理过的数据集
    - （DONE）学员将他们收集、评估和清理过的主数据集保存到 CSV 文件或 SQLite 数据库中。
* 学生能够根据自己所掌握的数据采取行动来得出结论（例如通过分析，可视化和/或模型)
    - （DONE）使用 Jupyter Notebook 中的 pandas 或 SQL 分析主数据集，并生成至少三（3）个独立的结论。
    - （DONE）在 Jupyter Notebook 中，使用 Python 绘图库或在 Tableau 中至少生成一（1）个标记的可视化对象。
    - （DONE）学员必须在他们的清洗数据中明确他们之后分析和可视化所依据的数据是建立在评估和清理的基础上。

### 报告
* 学员能够思考并描述他们的数据清洗过程
    - （DONE）学员需要言简意赅地介绍他们的数据清理。 这一文件（wrangle_report.pdf）大约只需要300-600字。
* 学员在他们清洗过的数据集中能够发现并描述出结论
    - （DONE）学员发现至少三（3）个结论，其中至少包含一个（1）可视化。这一文件（act_report.pdf）至少需要 250 个字。

### 项目文件
* 学员提交的文件夹中是否包含所有必需的文件
    - （DONE）wrangle_act.ipynb
    - （DONE）wrangle_report.pdf
    - （DONE）act_report.pdf
    - （DONE）并包括所有的数据集文件，如存储的主数据集，并使用在项目提交页面中指定的文件名和扩展名。   

## 个人期望结论假设
* 评分高低应该和转发数量/喜爱程度存在关系
* 评分高低和狗的种类存在关系
* 评分高低和狗的地位存在关系
* 评论的词云分析
* 各种评分的箱形分布图
* 评分的总体分布情况

**所以需要完成tweet-archive-master文档应包含以下内容，相应数据来源在括号中标识：**
* tweet_id 推特账号 （df_tweeter）
* text 推文（df_tweeter）
* timestamp 时间戳（df_tweeter）
* retweet-count 转推数（df_json）
* favorite-count 喜爱数 （df_json）
* rating 评分（df_tweeter）
* dog-name 狗名（df_tweeter）
* dog-status 狗的地位（df_tweeter）
* dog-types 狗的品种(df_pred)
* dog-prediction probabily 品种预测的概率(df_pred)
---
# Update 2018_04_03
## 存在的问题:
* 我们来观察下项目动机中的要点会发现，这里有2个问题是强制要求被标记且处理的：
    1），只需要原始的数据
    2），只需要包含图片的数据
    
* 关于狗的地位的问题
    多种地位的狗，其实最好是将他们保留下来
    因为text中可能有些地位是以大写开头的，部分大写的地位没有提取
    
* 狗名的提取还包括This is|Meet|name is|Say hello to|named 这几种不同类型的信号词
但我发现更正掉named的信号词的词条后，还有错误提取了冠词的现象，而这些现象往往都是以This is|Meet|等为提取信号词而错误提取的。
由于name本身不是我研究的主要对象，故还是保留了之提取named信号词的动作。其余的还是按照元数据提供的name信息进行分析


```python
# 导入所需模块
import pandas as pd
import numpy as np
import requests
import tweepy
import json
import os
import seaborn as sns
from IPython.display import display
import matplotlib.pyplot as plt
import re
import statsmodels.formula.api as smf
%matplotlib inline
%config InlineBackend.figure_format='retina'
#import wordcloud
```

# 收集数据
## 下载数据


```python
# 下载image_predictions.tsv数据
url1 = 'https://raw.githubusercontent.com/udacity/new-dand-advanced-china/master/%E6%95%B0%E6%8D%AE%E6%B8%85%E6%B4%97/WeRateDogs%E9%A1%B9%E7%9B%AE/image-predictions.tsv'
with open('image_predictions.tsv' , 'wb') as file:
    image_f = requests.get(url1)
    file.write(image_f.content)
image_predictions = pd.read_csv('image_predictions.tsv' , sep = '\t') 
#image_predictions.head(5)
```


```python
# 下载twitter-archive-enhanced.csv数据
url2 = 'https://raw.githubusercontent.com/udacity/new-dand-advanced-china/master/%E6%95%B0%E6%8D%AE%E6%B8%85%E6%B4%97/WeRateDogs%E9%A1%B9%E7%9B%AE/twitter-archive-enhanced.csv'
with open('twitter-archive-enhanced.csv' , 'wb') as file:
    twitter_f = requests.get(url2)
    file.write(twitter_f.content)
twitter_archive_enhanced = pd.read_csv('twitter-archive-enhanced.csv' , sep = ',') 
#twitter_archive_enhanced.head(5)
```


```python
# 由于众所周知的原因，无法注册tweeter，好在udacity准备了相关json数据的TXT格式以应用该project，下载tweet_json.txt数据
url3 = 'https://raw.githubusercontent.com/udacity/new-dand-advanced-china/master/%E6%95%B0%E6%8D%AE%E6%B8%85%E6%B4%97/WeRateDogs%E9%A1%B9%E7%9B%AE/tweet_json.txt'

with open('tweet_json.txt' , 'wb') as file:
    tweet_f = requests.get(url3)
    file.write(tweet_f.content)
#test = open('tweet_json.txt' , 'r')
#a = test.readlines()
#a

tweet_data = pd.DataFrame(columns=['tweet_id','retweet_count','favorite_count'])
with open('tweet_json.txt','r')as file:
    for line in file.readlines():
        dic = json.loads(line)
        #print(dic['id'])
        tweet_id = dic['id']
        retweet_count = dic['retweet_count']
        favorite_count = dic['favorite_count']
        tweet_data = tweet_data.append({'tweet_id' :tweet_id,'retweet_count':retweet_count,'favorite_count':favorite_count},ignore_index=True)
#tweet_data.head(5)

```


```python
#读取备份文件进行操作
df_pred= image_predictions.copy()
df_twitter = twitter_archive_enhanced.copy()
df_json = tweet_data.copy()
```

# 评估数据
分别对于df_twitter, df_pred, df_json三个数据集进行检查

## df_twitter数据集的检查


```python
df_twitter
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>in_reply_to_status_id</th>
      <th>in_reply_to_user_id</th>
      <th>timestamp</th>
      <th>source</th>
      <th>text</th>
      <th>retweeted_status_id</th>
      <th>retweeted_status_user_id</th>
      <th>retweeted_status_timestamp</th>
      <th>expanded_urls</th>
      <th>rating_numerator</th>
      <th>rating_denominator</th>
      <th>name</th>
      <th>doggo</th>
      <th>floofer</th>
      <th>pupper</th>
      <th>puppo</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>892420643555336193</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-08-01 16:23:56 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Phineas. He's a mystical boy. Only eve...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/892420643...</td>
      <td>13</td>
      <td>10</td>
      <td>Phineas</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1</th>
      <td>892177421306343426</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-08-01 00:17:27 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Tilly. She's just checking pup on you....</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/892177421...</td>
      <td>13</td>
      <td>10</td>
      <td>Tilly</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2</th>
      <td>891815181378084864</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-31 00:18:03 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Archie. He is a rare Norwegian Pouncin...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/891815181...</td>
      <td>12</td>
      <td>10</td>
      <td>Archie</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>3</th>
      <td>891689557279858688</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-30 15:58:51 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Darla. She commenced a snooze mid meal...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/891689557...</td>
      <td>13</td>
      <td>10</td>
      <td>Darla</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>4</th>
      <td>891327558926688256</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-29 16:00:24 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Franklin. He would like you to stop ca...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/891327558...</td>
      <td>12</td>
      <td>10</td>
      <td>Franklin</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>5</th>
      <td>891087950875897856</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-29 00:08:17 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Here we have a majestic great white breaching ...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/891087950...</td>
      <td>13</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>6</th>
      <td>890971913173991426</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-28 16:27:12 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Meet Jax. He enjoys ice cream so much he gets ...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://gofundme.com/ydvmve-surgery-for-jax,ht...</td>
      <td>13</td>
      <td>10</td>
      <td>Jax</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>7</th>
      <td>890729181411237888</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-28 00:22:40 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>When you watch your owner call another dog a g...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/890729181...</td>
      <td>13</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>8</th>
      <td>890609185150312448</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-27 16:25:51 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Zoey. She doesn't want to be one of th...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/890609185...</td>
      <td>13</td>
      <td>10</td>
      <td>Zoey</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>9</th>
      <td>890240255349198849</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-26 15:59:51 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Cassie. She is a college pup. Studying...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/890240255...</td>
      <td>14</td>
      <td>10</td>
      <td>Cassie</td>
      <td>doggo</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>10</th>
      <td>890006608113172480</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-26 00:31:25 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Koda. He is a South Australian decksha...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/890006608...</td>
      <td>13</td>
      <td>10</td>
      <td>Koda</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>11</th>
      <td>889880896479866881</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-25 16:11:53 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Bruno. He is a service shark. Only get...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/889880896...</td>
      <td>13</td>
      <td>10</td>
      <td>Bruno</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>12</th>
      <td>889665388333682689</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-25 01:55:32 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Here's a puppo that seems to be on the fence a...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/889665388...</td>
      <td>13</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>puppo</td>
    </tr>
    <tr>
      <th>13</th>
      <td>889638837579907072</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-25 00:10:02 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Ted. He does his best. Sometimes that'...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/889638837...</td>
      <td>12</td>
      <td>10</td>
      <td>Ted</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>14</th>
      <td>889531135344209921</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-24 17:02:04 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Stuart. He's sporting his favorite fan...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/889531135...</td>
      <td>13</td>
      <td>10</td>
      <td>Stuart</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>puppo</td>
    </tr>
    <tr>
      <th>15</th>
      <td>889278841981685760</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-24 00:19:32 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Oliver. You're witnessing one of his m...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/889278841...</td>
      <td>13</td>
      <td>10</td>
      <td>Oliver</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>16</th>
      <td>888917238123831296</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-23 00:22:39 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Jim. He found a fren. Taught him how t...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/888917238...</td>
      <td>12</td>
      <td>10</td>
      <td>Jim</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>17</th>
      <td>888804989199671297</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-22 16:56:37 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Zeke. He has a new stick. Very proud o...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/888804989...</td>
      <td>13</td>
      <td>10</td>
      <td>Zeke</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>18</th>
      <td>888554962724278272</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-22 00:23:06 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Ralphus. He's powering up. Attempting ...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/888554962...</td>
      <td>13</td>
      <td>10</td>
      <td>Ralphus</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>19</th>
      <td>888202515573088257</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-21 01:02:36 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>RT @dog_rates: This is Canela. She attempted s...</td>
      <td>8.874740e+17</td>
      <td>4.196984e+09</td>
      <td>2017-07-19 00:47:34 +0000</td>
      <td>https://twitter.com/dog_rates/status/887473957...</td>
      <td>13</td>
      <td>10</td>
      <td>Canela</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>20</th>
      <td>888078434458587136</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-20 16:49:33 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Gerald. He was just told he didn't get...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/888078434...</td>
      <td>12</td>
      <td>10</td>
      <td>Gerald</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>21</th>
      <td>887705289381826560</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-19 16:06:48 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Jeffrey. He has a monopoly on the pool...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/887705289...</td>
      <td>13</td>
      <td>10</td>
      <td>Jeffrey</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>22</th>
      <td>887517139158093824</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-19 03:39:09 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>I've yet to rate a Venezuelan Hover Wiener. Th...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/887517139...</td>
      <td>14</td>
      <td>10</td>
      <td>such</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>23</th>
      <td>887473957103951883</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-19 00:47:34 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Canela. She attempted some fancy porch...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/887473957...</td>
      <td>13</td>
      <td>10</td>
      <td>Canela</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>24</th>
      <td>887343217045368832</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-18 16:08:03 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>You may not have known you needed to see this ...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/887343217...</td>
      <td>13</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>25</th>
      <td>887101392804085760</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-18 00:07:08 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This... is a Jubilant Antarctic House Bear. We...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/887101392...</td>
      <td>12</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>26</th>
      <td>886983233522544640</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-17 16:17:36 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Maya. She's very shy. Rarely leaves he...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/886983233...</td>
      <td>13</td>
      <td>10</td>
      <td>Maya</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>27</th>
      <td>886736880519319552</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-16 23:58:41 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Mingus. He's a wonderful father to his...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://www.gofundme.com/mingusneedsus,https:/...</td>
      <td>13</td>
      <td>10</td>
      <td>Mingus</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>28</th>
      <td>886680336477933568</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-16 20:14:00 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Derek. He's late for a dog meeting. 13...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/886680336...</td>
      <td>13</td>
      <td>10</td>
      <td>Derek</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>29</th>
      <td>886366144734445568</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017-07-15 23:25:31 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is Roscoe. Another pupper fallen victim t...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/886366144...</td>
      <td>12</td>
      <td>10</td>
      <td>Roscoe</td>
      <td>None</td>
      <td>None</td>
      <td>pupper</td>
      <td>None</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2326</th>
      <td>666411507551481857</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-17 00:24:19 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is quite the dog. Gets really excited whe...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666411507...</td>
      <td>2</td>
      <td>10</td>
      <td>quite</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2327</th>
      <td>666407126856765440</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-17 00:06:54 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is a southern Vesuvius bumblegruff. Can d...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666407126...</td>
      <td>7</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2328</th>
      <td>666396247373291520</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 23:23:41 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Oh goodness. A super rare northeast Qdoba kang...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666396247...</td>
      <td>9</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2329</th>
      <td>666373753744588802</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 21:54:18 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Those are sunglasses and a jean jacket. 11/10 ...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666373753...</td>
      <td>11</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2330</th>
      <td>666362758909284353</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 21:10:36 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Unique dog here. Very small. Lives in containe...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666362758...</td>
      <td>6</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2331</th>
      <td>666353288456101888</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 20:32:58 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Here we have a mixed Asiago from the Galápagos...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666353288...</td>
      <td>8</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2332</th>
      <td>666345417576210432</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 20:01:42 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Look at this jokester thinking seat belt laws ...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666345417...</td>
      <td>10</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2333</th>
      <td>666337882303524864</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 19:31:45 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is an extremely rare horned Parthenon. No...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666337882...</td>
      <td>9</td>
      <td>10</td>
      <td>an</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2334</th>
      <td>666293911632134144</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 16:37:02 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is a funny dog. Weird toes. Won't come do...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666293911...</td>
      <td>3</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2335</th>
      <td>666287406224695296</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 16:11:11 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is an Albanian 3 1/2 legged  Episcopalian...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666287406...</td>
      <td>1</td>
      <td>2</td>
      <td>an</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2336</th>
      <td>666273097616637952</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 15:14:19 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Can take selfies 11/10 https://t.co/ws2AMaNwPW</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666273097...</td>
      <td>11</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2337</th>
      <td>666268910803644416</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 14:57:41 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Very concerned about fellow dog trapped in com...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666268910...</td>
      <td>10</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2338</th>
      <td>666104133288665088</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 04:02:55 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Not familiar with this breed. No tail (weird)....</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666104133...</td>
      <td>1</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2339</th>
      <td>666102155909144576</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 03:55:04 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Oh my. Here you are seeing an Adobe Setter giv...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666102155...</td>
      <td>11</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2340</th>
      <td>666099513787052032</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 03:44:34 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Can stand on stump for what seems like a while...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666099513...</td>
      <td>8</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2341</th>
      <td>666094000022159362</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 03:22:39 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This appears to be a Mongolian Presbyterian mi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666094000...</td>
      <td>9</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2342</th>
      <td>666082916733198337</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 02:38:37 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Here we have a well-established sunblockerspan...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666082916...</td>
      <td>6</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2343</th>
      <td>666073100786774016</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 01:59:36 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Let's hope this flight isn't Malaysian (lol). ...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666073100...</td>
      <td>10</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2344</th>
      <td>666071193221509120</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 01:52:02 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Here we have a northern speckled Rhododendron....</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666071193...</td>
      <td>9</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2345</th>
      <td>666063827256086533</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 01:22:45 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is the happiest dog you will ever see. Ve...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666063827...</td>
      <td>10</td>
      <td>10</td>
      <td>the</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2346</th>
      <td>666058600524156928</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 01:01:59 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Here is the Rand Paul of retrievers folks! He'...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666058600...</td>
      <td>8</td>
      <td>10</td>
      <td>the</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2347</th>
      <td>666057090499244032</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 00:55:59 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>My oh my. This is a rare blond Canadian terrie...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666057090...</td>
      <td>9</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2348</th>
      <td>666055525042405380</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 00:49:46 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Here is a Siberian heavily armored polar bear ...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666055525...</td>
      <td>10</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2349</th>
      <td>666051853826850816</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 00:35:11 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is an odd dog. Hard on the outside but lo...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666051853...</td>
      <td>2</td>
      <td>10</td>
      <td>an</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2350</th>
      <td>666050758794694657</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 00:30:50 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is a truly beautiful English Wilson Staff...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666050758...</td>
      <td>10</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2351</th>
      <td>666049248165822465</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 00:24:50 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Here we have a 1949 1st generation vulpix. Enj...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666049248...</td>
      <td>5</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2352</th>
      <td>666044226329800704</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-16 00:04:52 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is a purebred Piers Morgan. Loves to Netf...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666044226...</td>
      <td>6</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2353</th>
      <td>666033412701032449</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-15 23:21:54 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Here is a very happy pup. Big fan of well-main...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666033412...</td>
      <td>9</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2354</th>
      <td>666029285002620928</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-15 23:05:30 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>This is a western brown Mitsubishi terrier. Up...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666029285...</td>
      <td>7</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2355</th>
      <td>666020888022790149</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015-11-15 22:32:08 +0000</td>
      <td>&lt;a href="http://twitter.com/download/iphone" r...</td>
      <td>Here we have a Japanese Irish Setter. Lost eye...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://twitter.com/dog_rates/status/666020888...</td>
      <td>8</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
  </tbody>
</table>
<p>2356 rows × 17 columns</p>
</div>




```python
df_twitter.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2356 entries, 0 to 2355
    Data columns (total 17 columns):
    tweet_id                      2356 non-null int64
    in_reply_to_status_id         78 non-null float64
    in_reply_to_user_id           78 non-null float64
    timestamp                     2356 non-null object
    source                        2356 non-null object
    text                          2356 non-null object
    retweeted_status_id           181 non-null float64
    retweeted_status_user_id      181 non-null float64
    retweeted_status_timestamp    181 non-null object
    expanded_urls                 2297 non-null object
    rating_numerator              2356 non-null int64
    rating_denominator            2356 non-null int64
    name                          2356 non-null object
    doggo                         2356 non-null object
    floofer                       2356 non-null object
    pupper                        2356 non-null object
    puppo                         2356 non-null object
    dtypes: float64(4), int64(3), object(10)
    memory usage: 313.0+ KB



```python
#由于狗的地位只能有一种，观察发现部分数据狗的种类有重复分类现象，通过编程评估的方法进行筛选，得出存在重复标注现象的tweet_id如下：
temp = df_twitter.drop(['in_reply_to_status_id','in_reply_to_user_id','timestamp','source','text','retweeted_status_id','retweeted_status_user_id','retweeted_status_timestamp','expanded_urls','rating_numerator','rating_denominator','name'],axis=1)
#temp
temp_dog = pd.melt(temp, id_vars=["tweet_id"], value_vars=["doggo","floofer","pupper","puppo"])
#temp_dog
temp_dog = temp_dog[temp_dog.value!='None']
temp_dog = temp_dog.drop(['variable'],axis=1)
a = temp_dog.drop_duplicates(subset=['tweet_id'],keep='first')
b = temp_dog.drop_duplicates(subset=['tweet_id'],keep=False)
dupl_dog = a.append(b).drop_duplicates(subset=['tweet_id'],keep=False)
dupl_dog_list = list(dupl_dog.tweet_id)
dupl_dog.tweet_id
```




    191     855851453814013952
    200     854010172552949760
    460     817777686764523521
    531     808106460588765185
    565     802265048156610565
    575     801115127852503040
    705     785639753186217984
    733     781308096455073793
    778     775898661951791106
    822     770093767776997377
    889     759793422261743616
    956     751583847268179968
    1063    741067306818797568
    1113    733109485275860992
    Name: tweet_id, dtype: int64




```python
#缺少狗的地位的部分数据
none_list = temp['tweet_id'][(temp.doggo == 'None') & (temp.floofer == 'None') & (temp.pupper == 'None') & (temp.puppo =='None')]
none_list
```




    0       892420643555336193
    1       892177421306343426
    2       891815181378084864
    3       891689557279858688
    4       891327558926688256
    5       891087950875897856
    6       890971913173991426
    7       890729181411237888
    8       890609185150312448
    10      890006608113172480
    11      889880896479866881
    13      889638837579907072
    15      889278841981685760
    16      888917238123831296
    17      888804989199671297
    18      888554962724278272
    19      888202515573088257
    20      888078434458587136
    21      887705289381826560
    22      887517139158093824
    23      887473957103951883
    24      887343217045368832
    25      887101392804085760
    26      886983233522544640
    27      886736880519319552
    28      886680336477933568
    30      886267009285017600
    31      886258384151887873
    32      886054160059072513
    33      885984800019947520
                   ...        
    2326    666411507551481857
    2327    666407126856765440
    2328    666396247373291520
    2329    666373753744588802
    2330    666362758909284353
    2331    666353288456101888
    2332    666345417576210432
    2333    666337882303524864
    2334    666293911632134144
    2335    666287406224695296
    2336    666273097616637952
    2337    666268910803644416
    2338    666104133288665088
    2339    666102155909144576
    2340    666099513787052032
    2341    666094000022159362
    2342    666082916733198337
    2343    666073100786774016
    2344    666071193221509120
    2345    666063827256086533
    2346    666058600524156928
    2347    666057090499244032
    2348    666055525042405380
    2349    666051853826850816
    2350    666050758794694657
    2351    666049248165822465
    2352    666044226329800704
    2353    666033412701032449
    2354    666029285002620928
    2355    666020888022790149
    Name: tweet_id, Length: 1976, dtype: int64




```python
#采用编程检查的方法评估数据
temp_dog.value.value_counts()
df_twitter.name.value_counts()
df_twitter.rating_numerator.value_counts()
df_twitter.rating_denominator.value_counts()
```




    10     2333
    11        3
    50        3
    80        2
    20        2
    2         1
    16        1
    40        1
    70        1
    15        1
    90        1
    110       1
    120       1
    130       1
    150       1
    170       1
    7         1
    0         1
    Name: rating_denominator, dtype: int64




```python
df_twitter.text.sample(20)
```




    734     This is Oakley. He just got yelled at for goin...
    1647    Breathtaking pupper here. Should be on the cov...
    2188    This is Jeremy. He hasn't grown into his skin ...
    1309    Say hello to Cupcake. She's an Icelandic Dippe...
    376     This is Sailer. He waits on the roof for his o...
    548     Meet Sansa and Gary. They run along the fence ...
    380     Meet Tucker. It's his birthday. He's pupset wi...
    921     Here's a heartwarming scene of a single father...
    44      This is Noah. He can't believe someone made th...
    1006    This is Keurig. He apparently headbutts other ...
    2034    This is a Tuscaloosa Alcatraz named Jacob (Yac...
    629     RT @dog_rates: This is Butter. She can have wh...
    1260    The squad is back for St. Patrick's Day! ☘ 💚\n...
    985     This is Boomer. He's self-baptizing. Other dog...
    1278    This is Lucy. She doesn't understand fetch. 8/...
    1168    This is Oliver. Bath time is upon him. His fea...
    1617    Meet Gerbald. He just found out he's adopted. ...
    1357    This pupper doesn't understand gates. 10/10 so...
    1735    This is Hunter. He was playing with his ball m...
    1505    We usually don't rate penguins but this one is...
    Name: text, dtype: object



- **tweet_id的类型为int64，in_reply_to_status_id & in_reply_to_user_id 的类型为64位浮点，实际上这列不需要进行计算，我们需要将所有的ID列都转化为字符串格式**（Q）
- **timestamp时间戳的数据格式为object，应当转换为timedate** (Q)
- **部分name列信息缺失，需要补全狗的名字，同时部分狗的名字提取不正确** (Q)
- **狗的种类缺失** (Q)
- **狗的种类有重复标注现象** (Q)
- **expanded_urls只有2297 non-null object，相比表格的2356行缺失数据，需要补全** (Q)
- **狗的分类用了四列，应该合为一列**（T）
- **缺失retweeted_count 和 favorite_count 需要从df_json文件中提取增加**（Q）
- **source列的信息没有用，需要删除**（T）
- **部分Rating评分的分值不正确**（Q）
- **为了后续统计分析不受影响，所有缺失的数据应该被标记为np.nan的逻辑形式，而不是'None'的字符串形式**（Q）



## df_pred数据集的检查


```python
df_pred
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>jpg_url</th>
      <th>img_num</th>
      <th>p1</th>
      <th>p1_conf</th>
      <th>p1_dog</th>
      <th>p2</th>
      <th>p2_conf</th>
      <th>p2_dog</th>
      <th>p3</th>
      <th>p3_conf</th>
      <th>p3_dog</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>666020888022790149</td>
      <td>https://pbs.twimg.com/media/CT4udn0WwAA0aMy.jpg</td>
      <td>1</td>
      <td>Welsh_springer_spaniel</td>
      <td>0.465074</td>
      <td>True</td>
      <td>collie</td>
      <td>0.156665</td>
      <td>True</td>
      <td>Shetland_sheepdog</td>
      <td>0.061428</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1</th>
      <td>666029285002620928</td>
      <td>https://pbs.twimg.com/media/CT42GRgUYAA5iDo.jpg</td>
      <td>1</td>
      <td>redbone</td>
      <td>0.506826</td>
      <td>True</td>
      <td>miniature_pinscher</td>
      <td>0.074192</td>
      <td>True</td>
      <td>Rhodesian_ridgeback</td>
      <td>0.072010</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2</th>
      <td>666033412701032449</td>
      <td>https://pbs.twimg.com/media/CT4521TWwAEvMyu.jpg</td>
      <td>1</td>
      <td>German_shepherd</td>
      <td>0.596461</td>
      <td>True</td>
      <td>malinois</td>
      <td>0.138584</td>
      <td>True</td>
      <td>bloodhound</td>
      <td>0.116197</td>
      <td>True</td>
    </tr>
    <tr>
      <th>3</th>
      <td>666044226329800704</td>
      <td>https://pbs.twimg.com/media/CT5Dr8HUEAA-lEu.jpg</td>
      <td>1</td>
      <td>Rhodesian_ridgeback</td>
      <td>0.408143</td>
      <td>True</td>
      <td>redbone</td>
      <td>0.360687</td>
      <td>True</td>
      <td>miniature_pinscher</td>
      <td>0.222752</td>
      <td>True</td>
    </tr>
    <tr>
      <th>4</th>
      <td>666049248165822465</td>
      <td>https://pbs.twimg.com/media/CT5IQmsXIAAKY4A.jpg</td>
      <td>1</td>
      <td>miniature_pinscher</td>
      <td>0.560311</td>
      <td>True</td>
      <td>Rottweiler</td>
      <td>0.243682</td>
      <td>True</td>
      <td>Doberman</td>
      <td>0.154629</td>
      <td>True</td>
    </tr>
    <tr>
      <th>5</th>
      <td>666050758794694657</td>
      <td>https://pbs.twimg.com/media/CT5Jof1WUAEuVxN.jpg</td>
      <td>1</td>
      <td>Bernese_mountain_dog</td>
      <td>0.651137</td>
      <td>True</td>
      <td>English_springer</td>
      <td>0.263788</td>
      <td>True</td>
      <td>Greater_Swiss_Mountain_dog</td>
      <td>0.016199</td>
      <td>True</td>
    </tr>
    <tr>
      <th>6</th>
      <td>666051853826850816</td>
      <td>https://pbs.twimg.com/media/CT5KoJ1WoAAJash.jpg</td>
      <td>1</td>
      <td>box_turtle</td>
      <td>0.933012</td>
      <td>False</td>
      <td>mud_turtle</td>
      <td>0.045885</td>
      <td>False</td>
      <td>terrapin</td>
      <td>0.017885</td>
      <td>False</td>
    </tr>
    <tr>
      <th>7</th>
      <td>666055525042405380</td>
      <td>https://pbs.twimg.com/media/CT5N9tpXIAAifs1.jpg</td>
      <td>1</td>
      <td>chow</td>
      <td>0.692517</td>
      <td>True</td>
      <td>Tibetan_mastiff</td>
      <td>0.058279</td>
      <td>True</td>
      <td>fur_coat</td>
      <td>0.054449</td>
      <td>False</td>
    </tr>
    <tr>
      <th>8</th>
      <td>666057090499244032</td>
      <td>https://pbs.twimg.com/media/CT5PY90WoAAQGLo.jpg</td>
      <td>1</td>
      <td>shopping_cart</td>
      <td>0.962465</td>
      <td>False</td>
      <td>shopping_basket</td>
      <td>0.014594</td>
      <td>False</td>
      <td>golden_retriever</td>
      <td>0.007959</td>
      <td>True</td>
    </tr>
    <tr>
      <th>9</th>
      <td>666058600524156928</td>
      <td>https://pbs.twimg.com/media/CT5Qw94XAAA_2dP.jpg</td>
      <td>1</td>
      <td>miniature_poodle</td>
      <td>0.201493</td>
      <td>True</td>
      <td>komondor</td>
      <td>0.192305</td>
      <td>True</td>
      <td>soft-coated_wheaten_terrier</td>
      <td>0.082086</td>
      <td>True</td>
    </tr>
    <tr>
      <th>10</th>
      <td>666063827256086533</td>
      <td>https://pbs.twimg.com/media/CT5Vg_wXIAAXfnj.jpg</td>
      <td>1</td>
      <td>golden_retriever</td>
      <td>0.775930</td>
      <td>True</td>
      <td>Tibetan_mastiff</td>
      <td>0.093718</td>
      <td>True</td>
      <td>Labrador_retriever</td>
      <td>0.072427</td>
      <td>True</td>
    </tr>
    <tr>
      <th>11</th>
      <td>666071193221509120</td>
      <td>https://pbs.twimg.com/media/CT5cN_3WEAAlOoZ.jpg</td>
      <td>1</td>
      <td>Gordon_setter</td>
      <td>0.503672</td>
      <td>True</td>
      <td>Yorkshire_terrier</td>
      <td>0.174201</td>
      <td>True</td>
      <td>Pekinese</td>
      <td>0.109454</td>
      <td>True</td>
    </tr>
    <tr>
      <th>12</th>
      <td>666073100786774016</td>
      <td>https://pbs.twimg.com/media/CT5d9DZXAAALcwe.jpg</td>
      <td>1</td>
      <td>Walker_hound</td>
      <td>0.260857</td>
      <td>True</td>
      <td>English_foxhound</td>
      <td>0.175382</td>
      <td>True</td>
      <td>Ibizan_hound</td>
      <td>0.097471</td>
      <td>True</td>
    </tr>
    <tr>
      <th>13</th>
      <td>666082916733198337</td>
      <td>https://pbs.twimg.com/media/CT5m4VGWEAAtKc8.jpg</td>
      <td>1</td>
      <td>pug</td>
      <td>0.489814</td>
      <td>True</td>
      <td>bull_mastiff</td>
      <td>0.404722</td>
      <td>True</td>
      <td>French_bulldog</td>
      <td>0.048960</td>
      <td>True</td>
    </tr>
    <tr>
      <th>14</th>
      <td>666094000022159362</td>
      <td>https://pbs.twimg.com/media/CT5w9gUW4AAsBNN.jpg</td>
      <td>1</td>
      <td>bloodhound</td>
      <td>0.195217</td>
      <td>True</td>
      <td>German_shepherd</td>
      <td>0.078260</td>
      <td>True</td>
      <td>malinois</td>
      <td>0.075628</td>
      <td>True</td>
    </tr>
    <tr>
      <th>15</th>
      <td>666099513787052032</td>
      <td>https://pbs.twimg.com/media/CT51-JJUEAA6hV8.jpg</td>
      <td>1</td>
      <td>Lhasa</td>
      <td>0.582330</td>
      <td>True</td>
      <td>Shih-Tzu</td>
      <td>0.166192</td>
      <td>True</td>
      <td>Dandie_Dinmont</td>
      <td>0.089688</td>
      <td>True</td>
    </tr>
    <tr>
      <th>16</th>
      <td>666102155909144576</td>
      <td>https://pbs.twimg.com/media/CT54YGiWUAEZnoK.jpg</td>
      <td>1</td>
      <td>English_setter</td>
      <td>0.298617</td>
      <td>True</td>
      <td>Newfoundland</td>
      <td>0.149842</td>
      <td>True</td>
      <td>borzoi</td>
      <td>0.133649</td>
      <td>True</td>
    </tr>
    <tr>
      <th>17</th>
      <td>666104133288665088</td>
      <td>https://pbs.twimg.com/media/CT56LSZWoAAlJj2.jpg</td>
      <td>1</td>
      <td>hen</td>
      <td>0.965932</td>
      <td>False</td>
      <td>cock</td>
      <td>0.033919</td>
      <td>False</td>
      <td>partridge</td>
      <td>0.000052</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>666268910803644416</td>
      <td>https://pbs.twimg.com/media/CT8QCd1WEAADXws.jpg</td>
      <td>1</td>
      <td>desktop_computer</td>
      <td>0.086502</td>
      <td>False</td>
      <td>desk</td>
      <td>0.085547</td>
      <td>False</td>
      <td>bookcase</td>
      <td>0.079480</td>
      <td>False</td>
    </tr>
    <tr>
      <th>19</th>
      <td>666273097616637952</td>
      <td>https://pbs.twimg.com/media/CT8T1mtUwAA3aqm.jpg</td>
      <td>1</td>
      <td>Italian_greyhound</td>
      <td>0.176053</td>
      <td>True</td>
      <td>toy_terrier</td>
      <td>0.111884</td>
      <td>True</td>
      <td>basenji</td>
      <td>0.111152</td>
      <td>True</td>
    </tr>
    <tr>
      <th>20</th>
      <td>666287406224695296</td>
      <td>https://pbs.twimg.com/media/CT8g3BpUEAAuFjg.jpg</td>
      <td>1</td>
      <td>Maltese_dog</td>
      <td>0.857531</td>
      <td>True</td>
      <td>toy_poodle</td>
      <td>0.063064</td>
      <td>True</td>
      <td>miniature_poodle</td>
      <td>0.025581</td>
      <td>True</td>
    </tr>
    <tr>
      <th>21</th>
      <td>666293911632134144</td>
      <td>https://pbs.twimg.com/media/CT8mx7KW4AEQu8N.jpg</td>
      <td>1</td>
      <td>three-toed_sloth</td>
      <td>0.914671</td>
      <td>False</td>
      <td>otter</td>
      <td>0.015250</td>
      <td>False</td>
      <td>great_grey_owl</td>
      <td>0.013207</td>
      <td>False</td>
    </tr>
    <tr>
      <th>22</th>
      <td>666337882303524864</td>
      <td>https://pbs.twimg.com/media/CT9OwFIWEAMuRje.jpg</td>
      <td>1</td>
      <td>ox</td>
      <td>0.416669</td>
      <td>False</td>
      <td>Newfoundland</td>
      <td>0.278407</td>
      <td>True</td>
      <td>groenendael</td>
      <td>0.102643</td>
      <td>True</td>
    </tr>
    <tr>
      <th>23</th>
      <td>666345417576210432</td>
      <td>https://pbs.twimg.com/media/CT9Vn7PWoAA_ZCM.jpg</td>
      <td>1</td>
      <td>golden_retriever</td>
      <td>0.858744</td>
      <td>True</td>
      <td>Chesapeake_Bay_retriever</td>
      <td>0.054787</td>
      <td>True</td>
      <td>Labrador_retriever</td>
      <td>0.014241</td>
      <td>True</td>
    </tr>
    <tr>
      <th>24</th>
      <td>666353288456101888</td>
      <td>https://pbs.twimg.com/media/CT9cx0tUEAAhNN_.jpg</td>
      <td>1</td>
      <td>malamute</td>
      <td>0.336874</td>
      <td>True</td>
      <td>Siberian_husky</td>
      <td>0.147655</td>
      <td>True</td>
      <td>Eskimo_dog</td>
      <td>0.093412</td>
      <td>True</td>
    </tr>
    <tr>
      <th>25</th>
      <td>666362758909284353</td>
      <td>https://pbs.twimg.com/media/CT9lXGsUcAAyUFt.jpg</td>
      <td>1</td>
      <td>guinea_pig</td>
      <td>0.996496</td>
      <td>False</td>
      <td>skunk</td>
      <td>0.002402</td>
      <td>False</td>
      <td>hamster</td>
      <td>0.000461</td>
      <td>False</td>
    </tr>
    <tr>
      <th>26</th>
      <td>666373753744588802</td>
      <td>https://pbs.twimg.com/media/CT9vZEYWUAAlZ05.jpg</td>
      <td>1</td>
      <td>soft-coated_wheaten_terrier</td>
      <td>0.326467</td>
      <td>True</td>
      <td>Afghan_hound</td>
      <td>0.259551</td>
      <td>True</td>
      <td>briard</td>
      <td>0.206803</td>
      <td>True</td>
    </tr>
    <tr>
      <th>27</th>
      <td>666396247373291520</td>
      <td>https://pbs.twimg.com/media/CT-D2ZHWIAA3gK1.jpg</td>
      <td>1</td>
      <td>Chihuahua</td>
      <td>0.978108</td>
      <td>True</td>
      <td>toy_terrier</td>
      <td>0.009397</td>
      <td>True</td>
      <td>papillon</td>
      <td>0.004577</td>
      <td>True</td>
    </tr>
    <tr>
      <th>28</th>
      <td>666407126856765440</td>
      <td>https://pbs.twimg.com/media/CT-NvwmW4AAugGZ.jpg</td>
      <td>1</td>
      <td>black-and-tan_coonhound</td>
      <td>0.529139</td>
      <td>True</td>
      <td>bloodhound</td>
      <td>0.244220</td>
      <td>True</td>
      <td>flat-coated_retriever</td>
      <td>0.173810</td>
      <td>True</td>
    </tr>
    <tr>
      <th>29</th>
      <td>666411507551481857</td>
      <td>https://pbs.twimg.com/media/CT-RugiWIAELEaq.jpg</td>
      <td>1</td>
      <td>coho</td>
      <td>0.404640</td>
      <td>False</td>
      <td>barracouta</td>
      <td>0.271485</td>
      <td>False</td>
      <td>gar</td>
      <td>0.189945</td>
      <td>False</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2045</th>
      <td>886366144734445568</td>
      <td>https://pbs.twimg.com/media/DE0BTnQUwAApKEH.jpg</td>
      <td>1</td>
      <td>French_bulldog</td>
      <td>0.999201</td>
      <td>True</td>
      <td>Chihuahua</td>
      <td>0.000361</td>
      <td>True</td>
      <td>Boston_bull</td>
      <td>0.000076</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2046</th>
      <td>886680336477933568</td>
      <td>https://pbs.twimg.com/media/DE4fEDzWAAAyHMM.jpg</td>
      <td>1</td>
      <td>convertible</td>
      <td>0.738995</td>
      <td>False</td>
      <td>sports_car</td>
      <td>0.139952</td>
      <td>False</td>
      <td>car_wheel</td>
      <td>0.044173</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2047</th>
      <td>886736880519319552</td>
      <td>https://pbs.twimg.com/media/DE5Se8FXcAAJFx4.jpg</td>
      <td>1</td>
      <td>kuvasz</td>
      <td>0.309706</td>
      <td>True</td>
      <td>Great_Pyrenees</td>
      <td>0.186136</td>
      <td>True</td>
      <td>Dandie_Dinmont</td>
      <td>0.086346</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2048</th>
      <td>886983233522544640</td>
      <td>https://pbs.twimg.com/media/DE8yicJW0AAAvBJ.jpg</td>
      <td>2</td>
      <td>Chihuahua</td>
      <td>0.793469</td>
      <td>True</td>
      <td>toy_terrier</td>
      <td>0.143528</td>
      <td>True</td>
      <td>can_opener</td>
      <td>0.032253</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2049</th>
      <td>887101392804085760</td>
      <td>https://pbs.twimg.com/media/DE-eAq6UwAA-jaE.jpg</td>
      <td>1</td>
      <td>Samoyed</td>
      <td>0.733942</td>
      <td>True</td>
      <td>Eskimo_dog</td>
      <td>0.035029</td>
      <td>True</td>
      <td>Staffordshire_bullterrier</td>
      <td>0.029705</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2050</th>
      <td>887343217045368832</td>
      <td>https://pbs.twimg.com/ext_tw_video_thumb/88734...</td>
      <td>1</td>
      <td>Mexican_hairless</td>
      <td>0.330741</td>
      <td>True</td>
      <td>sea_lion</td>
      <td>0.275645</td>
      <td>False</td>
      <td>Weimaraner</td>
      <td>0.134203</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2051</th>
      <td>887473957103951883</td>
      <td>https://pbs.twimg.com/media/DFDw2tyUQAAAFke.jpg</td>
      <td>2</td>
      <td>Pembroke</td>
      <td>0.809197</td>
      <td>True</td>
      <td>Rhodesian_ridgeback</td>
      <td>0.054950</td>
      <td>True</td>
      <td>beagle</td>
      <td>0.038915</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2052</th>
      <td>887517139158093824</td>
      <td>https://pbs.twimg.com/ext_tw_video_thumb/88751...</td>
      <td>1</td>
      <td>limousine</td>
      <td>0.130432</td>
      <td>False</td>
      <td>tow_truck</td>
      <td>0.029175</td>
      <td>False</td>
      <td>shopping_cart</td>
      <td>0.026321</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2053</th>
      <td>887705289381826560</td>
      <td>https://pbs.twimg.com/media/DFHDQBbXgAEqY7t.jpg</td>
      <td>1</td>
      <td>basset</td>
      <td>0.821664</td>
      <td>True</td>
      <td>redbone</td>
      <td>0.087582</td>
      <td>True</td>
      <td>Weimaraner</td>
      <td>0.026236</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2054</th>
      <td>888078434458587136</td>
      <td>https://pbs.twimg.com/media/DFMWn56WsAAkA7B.jpg</td>
      <td>1</td>
      <td>French_bulldog</td>
      <td>0.995026</td>
      <td>True</td>
      <td>pug</td>
      <td>0.000932</td>
      <td>True</td>
      <td>bull_mastiff</td>
      <td>0.000903</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2055</th>
      <td>888202515573088257</td>
      <td>https://pbs.twimg.com/media/DFDw2tyUQAAAFke.jpg</td>
      <td>2</td>
      <td>Pembroke</td>
      <td>0.809197</td>
      <td>True</td>
      <td>Rhodesian_ridgeback</td>
      <td>0.054950</td>
      <td>True</td>
      <td>beagle</td>
      <td>0.038915</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2056</th>
      <td>888554962724278272</td>
      <td>https://pbs.twimg.com/media/DFTH_O-UQAACu20.jpg</td>
      <td>3</td>
      <td>Siberian_husky</td>
      <td>0.700377</td>
      <td>True</td>
      <td>Eskimo_dog</td>
      <td>0.166511</td>
      <td>True</td>
      <td>malamute</td>
      <td>0.111411</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2057</th>
      <td>888804989199671297</td>
      <td>https://pbs.twimg.com/media/DFWra-3VYAA2piG.jpg</td>
      <td>1</td>
      <td>golden_retriever</td>
      <td>0.469760</td>
      <td>True</td>
      <td>Labrador_retriever</td>
      <td>0.184172</td>
      <td>True</td>
      <td>English_setter</td>
      <td>0.073482</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2058</th>
      <td>888917238123831296</td>
      <td>https://pbs.twimg.com/media/DFYRgsOUQAARGhO.jpg</td>
      <td>1</td>
      <td>golden_retriever</td>
      <td>0.714719</td>
      <td>True</td>
      <td>Tibetan_mastiff</td>
      <td>0.120184</td>
      <td>True</td>
      <td>Labrador_retriever</td>
      <td>0.105506</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2059</th>
      <td>889278841981685760</td>
      <td>https://pbs.twimg.com/ext_tw_video_thumb/88927...</td>
      <td>1</td>
      <td>whippet</td>
      <td>0.626152</td>
      <td>True</td>
      <td>borzoi</td>
      <td>0.194742</td>
      <td>True</td>
      <td>Saluki</td>
      <td>0.027351</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2060</th>
      <td>889531135344209921</td>
      <td>https://pbs.twimg.com/media/DFg_2PVW0AEHN3p.jpg</td>
      <td>1</td>
      <td>golden_retriever</td>
      <td>0.953442</td>
      <td>True</td>
      <td>Labrador_retriever</td>
      <td>0.013834</td>
      <td>True</td>
      <td>redbone</td>
      <td>0.007958</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2061</th>
      <td>889638837579907072</td>
      <td>https://pbs.twimg.com/media/DFihzFfXsAYGDPR.jpg</td>
      <td>1</td>
      <td>French_bulldog</td>
      <td>0.991650</td>
      <td>True</td>
      <td>boxer</td>
      <td>0.002129</td>
      <td>True</td>
      <td>Staffordshire_bullterrier</td>
      <td>0.001498</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2062</th>
      <td>889665388333682689</td>
      <td>https://pbs.twimg.com/media/DFi579UWsAAatzw.jpg</td>
      <td>1</td>
      <td>Pembroke</td>
      <td>0.966327</td>
      <td>True</td>
      <td>Cardigan</td>
      <td>0.027356</td>
      <td>True</td>
      <td>basenji</td>
      <td>0.004633</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2063</th>
      <td>889880896479866881</td>
      <td>https://pbs.twimg.com/media/DFl99B1WsAITKsg.jpg</td>
      <td>1</td>
      <td>French_bulldog</td>
      <td>0.377417</td>
      <td>True</td>
      <td>Labrador_retriever</td>
      <td>0.151317</td>
      <td>True</td>
      <td>muzzle</td>
      <td>0.082981</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2064</th>
      <td>890006608113172480</td>
      <td>https://pbs.twimg.com/media/DFnwSY4WAAAMliS.jpg</td>
      <td>1</td>
      <td>Samoyed</td>
      <td>0.957979</td>
      <td>True</td>
      <td>Pomeranian</td>
      <td>0.013884</td>
      <td>True</td>
      <td>chow</td>
      <td>0.008167</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2065</th>
      <td>890240255349198849</td>
      <td>https://pbs.twimg.com/media/DFrEyVuW0AAO3t9.jpg</td>
      <td>1</td>
      <td>Pembroke</td>
      <td>0.511319</td>
      <td>True</td>
      <td>Cardigan</td>
      <td>0.451038</td>
      <td>True</td>
      <td>Chihuahua</td>
      <td>0.029248</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2066</th>
      <td>890609185150312448</td>
      <td>https://pbs.twimg.com/media/DFwUU__XcAEpyXI.jpg</td>
      <td>1</td>
      <td>Irish_terrier</td>
      <td>0.487574</td>
      <td>True</td>
      <td>Irish_setter</td>
      <td>0.193054</td>
      <td>True</td>
      <td>Chesapeake_Bay_retriever</td>
      <td>0.118184</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2067</th>
      <td>890729181411237888</td>
      <td>https://pbs.twimg.com/media/DFyBahAVwAAhUTd.jpg</td>
      <td>2</td>
      <td>Pomeranian</td>
      <td>0.566142</td>
      <td>True</td>
      <td>Eskimo_dog</td>
      <td>0.178406</td>
      <td>True</td>
      <td>Pembroke</td>
      <td>0.076507</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2068</th>
      <td>890971913173991426</td>
      <td>https://pbs.twimg.com/media/DF1eOmZXUAALUcq.jpg</td>
      <td>1</td>
      <td>Appenzeller</td>
      <td>0.341703</td>
      <td>True</td>
      <td>Border_collie</td>
      <td>0.199287</td>
      <td>True</td>
      <td>ice_lolly</td>
      <td>0.193548</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2069</th>
      <td>891087950875897856</td>
      <td>https://pbs.twimg.com/media/DF3HwyEWsAABqE6.jpg</td>
      <td>1</td>
      <td>Chesapeake_Bay_retriever</td>
      <td>0.425595</td>
      <td>True</td>
      <td>Irish_terrier</td>
      <td>0.116317</td>
      <td>True</td>
      <td>Indian_elephant</td>
      <td>0.076902</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2070</th>
      <td>891327558926688256</td>
      <td>https://pbs.twimg.com/media/DF6hr6BUMAAzZgT.jpg</td>
      <td>2</td>
      <td>basset</td>
      <td>0.555712</td>
      <td>True</td>
      <td>English_springer</td>
      <td>0.225770</td>
      <td>True</td>
      <td>German_short-haired_pointer</td>
      <td>0.175219</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2071</th>
      <td>891689557279858688</td>
      <td>https://pbs.twimg.com/media/DF_q7IAWsAEuuN8.jpg</td>
      <td>1</td>
      <td>paper_towel</td>
      <td>0.170278</td>
      <td>False</td>
      <td>Labrador_retriever</td>
      <td>0.168086</td>
      <td>True</td>
      <td>spatula</td>
      <td>0.040836</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2072</th>
      <td>891815181378084864</td>
      <td>https://pbs.twimg.com/media/DGBdLU1WsAANxJ9.jpg</td>
      <td>1</td>
      <td>Chihuahua</td>
      <td>0.716012</td>
      <td>True</td>
      <td>malamute</td>
      <td>0.078253</td>
      <td>True</td>
      <td>kelpie</td>
      <td>0.031379</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2073</th>
      <td>892177421306343426</td>
      <td>https://pbs.twimg.com/media/DGGmoV4XsAAUL6n.jpg</td>
      <td>1</td>
      <td>Chihuahua</td>
      <td>0.323581</td>
      <td>True</td>
      <td>Pekinese</td>
      <td>0.090647</td>
      <td>True</td>
      <td>papillon</td>
      <td>0.068957</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2074</th>
      <td>892420643555336193</td>
      <td>https://pbs.twimg.com/media/DGKD1-bXoAAIAUK.jpg</td>
      <td>1</td>
      <td>orange</td>
      <td>0.097049</td>
      <td>False</td>
      <td>bagel</td>
      <td>0.085851</td>
      <td>False</td>
      <td>banana</td>
      <td>0.076110</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>2075 rows × 12 columns</p>
</div>




```python
df_pred.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2075 entries, 0 to 2074
    Data columns (total 12 columns):
    tweet_id    2075 non-null int64
    jpg_url     2075 non-null object
    img_num     2075 non-null int64
    p1          2075 non-null object
    p1_conf     2075 non-null float64
    p1_dog      2075 non-null bool
    p2          2075 non-null object
    p2_conf     2075 non-null float64
    p2_dog      2075 non-null bool
    p3          2075 non-null object
    p3_conf     2075 non-null float64
    p3_dog      2075 non-null bool
    dtypes: bool(3), float64(3), int64(2), object(4)
    memory usage: 152.1+ KB



```python
#筛选出不是狗狗的部分
df_pred['tweet_id'][(df_pred.p1_dog==False) & (df_pred.p2_dog==False) & (df_pred.p3_dog==False)]
```




    6       666051853826850816
    17      666104133288665088
    18      666268910803644416
    21      666293911632134144
    25      666362758909284353
    29      666411507551481857
    45      666786068205871104
    50      666837028449972224
    51      666983947667116034
    53      667012601033924608
    56      667065535570550784
    69      667188689915760640
    73      667369227918143488
    77      667437278097252352
    78      667443425659232256
    93      667549055577362432
    94      667550882905632768
    96      667724302356258817
    98      667766675769573376
    100     667782464991965184
    106     667866724293877760
    107     667873844930215936
    112     667911425562669056
    115     667937095915278337
    117     668142349051129856
    118     668154635664932864
    123     668226093875376128
    130     668291999406125056
    132     668466899341221888
    140     668544745690562560
                   ...        
    1839    837482249356513284
    1844    838916489579200512
    1847    839290600511926273
    1851    840370681858686976
    1853    840696689258311684
    1869    844580511645339650
    1886    847962785489326080
    1887    847971574464610304
    1891    849051919805034497
    1892    849336543269576704
    1900    851464819735769094
    1902    851861385021730816
    1905    852226086759018497
    1906    852311364735569921
    1910    853299958564483072
    1931    859074603037188101
    1936    860184849394610176
    1937    860276583193509888
    1940    860924035999428608
    1946    862457590147678208
    1953    863907417377173506
    1956    864873206498414592
    1975    870063196459192321
    1979    870804317367881728
    2012    879050749262655488
    2021    880935762899988482
    2022    881268444196462592
    2046    886680336477933568
    2052    887517139158093824
    2074    892420643555336193
    Name: tweet_id, Length: 324, dtype: int64



- **tweet_id 和 img_num的类型为int64，实际上这列不需要进行计算，我们需要将这两列都转化为字符串格式**（Q）

## df_json数据集的检查


```python
df_json
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>retweet_count</th>
      <th>favorite_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>892420643555336193</td>
      <td>8842</td>
      <td>39492</td>
    </tr>
    <tr>
      <th>1</th>
      <td>892177421306343426</td>
      <td>6480</td>
      <td>33786</td>
    </tr>
    <tr>
      <th>2</th>
      <td>891815181378084864</td>
      <td>4301</td>
      <td>25445</td>
    </tr>
    <tr>
      <th>3</th>
      <td>891689557279858688</td>
      <td>8925</td>
      <td>42863</td>
    </tr>
    <tr>
      <th>4</th>
      <td>891327558926688256</td>
      <td>9721</td>
      <td>41016</td>
    </tr>
    <tr>
      <th>5</th>
      <td>891087950875897856</td>
      <td>3240</td>
      <td>20548</td>
    </tr>
    <tr>
      <th>6</th>
      <td>890971913173991426</td>
      <td>2142</td>
      <td>12053</td>
    </tr>
    <tr>
      <th>7</th>
      <td>890729181411237888</td>
      <td>19548</td>
      <td>66596</td>
    </tr>
    <tr>
      <th>8</th>
      <td>890609185150312448</td>
      <td>4403</td>
      <td>28187</td>
    </tr>
    <tr>
      <th>9</th>
      <td>890240255349198849</td>
      <td>7684</td>
      <td>32467</td>
    </tr>
    <tr>
      <th>10</th>
      <td>890006608113172480</td>
      <td>7584</td>
      <td>31127</td>
    </tr>
    <tr>
      <th>11</th>
      <td>889880896479866881</td>
      <td>5116</td>
      <td>28208</td>
    </tr>
    <tr>
      <th>12</th>
      <td>889665388333682689</td>
      <td>8502</td>
      <td>38745</td>
    </tr>
    <tr>
      <th>13</th>
      <td>889638837579907072</td>
      <td>4705</td>
      <td>27633</td>
    </tr>
    <tr>
      <th>14</th>
      <td>889531135344209921</td>
      <td>2309</td>
      <td>15329</td>
    </tr>
    <tr>
      <th>15</th>
      <td>889278841981685760</td>
      <td>5635</td>
      <td>25712</td>
    </tr>
    <tr>
      <th>16</th>
      <td>888917238123831296</td>
      <td>4681</td>
      <td>29555</td>
    </tr>
    <tr>
      <th>17</th>
      <td>888804989199671297</td>
      <td>4535</td>
      <td>26021</td>
    </tr>
    <tr>
      <th>18</th>
      <td>888554962724278272</td>
      <td>3722</td>
      <td>20267</td>
    </tr>
    <tr>
      <th>19</th>
      <td>888078434458587136</td>
      <td>3637</td>
      <td>22144</td>
    </tr>
    <tr>
      <th>20</th>
      <td>887705289381826560</td>
      <td>5584</td>
      <td>30690</td>
    </tr>
    <tr>
      <th>21</th>
      <td>887517139158093824</td>
      <td>12053</td>
      <td>46940</td>
    </tr>
    <tr>
      <th>22</th>
      <td>887473957103951883</td>
      <td>18813</td>
      <td>70007</td>
    </tr>
    <tr>
      <th>23</th>
      <td>887343217045368832</td>
      <td>10713</td>
      <td>34223</td>
    </tr>
    <tr>
      <th>24</th>
      <td>887101392804085760</td>
      <td>6147</td>
      <td>31045</td>
    </tr>
    <tr>
      <th>25</th>
      <td>886983233522544640</td>
      <td>8045</td>
      <td>35786</td>
    </tr>
    <tr>
      <th>26</th>
      <td>886736880519319552</td>
      <td>3420</td>
      <td>12286</td>
    </tr>
    <tr>
      <th>27</th>
      <td>886680336477933568</td>
      <td>4597</td>
      <td>22802</td>
    </tr>
    <tr>
      <th>28</th>
      <td>886366144734445568</td>
      <td>3297</td>
      <td>21488</td>
    </tr>
    <tr>
      <th>29</th>
      <td>886267009285017600</td>
      <td>4</td>
      <td>117</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2322</th>
      <td>666411507551481857</td>
      <td>337</td>
      <td>457</td>
    </tr>
    <tr>
      <th>2323</th>
      <td>666407126856765440</td>
      <td>43</td>
      <td>113</td>
    </tr>
    <tr>
      <th>2324</th>
      <td>666396247373291520</td>
      <td>91</td>
      <td>171</td>
    </tr>
    <tr>
      <th>2325</th>
      <td>666373753744588802</td>
      <td>99</td>
      <td>194</td>
    </tr>
    <tr>
      <th>2326</th>
      <td>666362758909284353</td>
      <td>590</td>
      <td>801</td>
    </tr>
    <tr>
      <th>2327</th>
      <td>666353288456101888</td>
      <td>76</td>
      <td>228</td>
    </tr>
    <tr>
      <th>2328</th>
      <td>666345417576210432</td>
      <td>146</td>
      <td>308</td>
    </tr>
    <tr>
      <th>2329</th>
      <td>666337882303524864</td>
      <td>96</td>
      <td>203</td>
    </tr>
    <tr>
      <th>2330</th>
      <td>666293911632134144</td>
      <td>365</td>
      <td>519</td>
    </tr>
    <tr>
      <th>2331</th>
      <td>666287406224695296</td>
      <td>71</td>
      <td>152</td>
    </tr>
    <tr>
      <th>2332</th>
      <td>666273097616637952</td>
      <td>81</td>
      <td>183</td>
    </tr>
    <tr>
      <th>2333</th>
      <td>666268910803644416</td>
      <td>37</td>
      <td>108</td>
    </tr>
    <tr>
      <th>2334</th>
      <td>666104133288665088</td>
      <td>6835</td>
      <td>14703</td>
    </tr>
    <tr>
      <th>2335</th>
      <td>666102155909144576</td>
      <td>15</td>
      <td>81</td>
    </tr>
    <tr>
      <th>2336</th>
      <td>666099513787052032</td>
      <td>73</td>
      <td>160</td>
    </tr>
    <tr>
      <th>2337</th>
      <td>666094000022159362</td>
      <td>78</td>
      <td>168</td>
    </tr>
    <tr>
      <th>2338</th>
      <td>666082916733198337</td>
      <td>47</td>
      <td>121</td>
    </tr>
    <tr>
      <th>2339</th>
      <td>666073100786774016</td>
      <td>173</td>
      <td>334</td>
    </tr>
    <tr>
      <th>2340</th>
      <td>666071193221509120</td>
      <td>67</td>
      <td>154</td>
    </tr>
    <tr>
      <th>2341</th>
      <td>666063827256086533</td>
      <td>230</td>
      <td>494</td>
    </tr>
    <tr>
      <th>2342</th>
      <td>666058600524156928</td>
      <td>61</td>
      <td>117</td>
    </tr>
    <tr>
      <th>2343</th>
      <td>666057090499244032</td>
      <td>146</td>
      <td>304</td>
    </tr>
    <tr>
      <th>2344</th>
      <td>666055525042405380</td>
      <td>261</td>
      <td>449</td>
    </tr>
    <tr>
      <th>2345</th>
      <td>666051853826850816</td>
      <td>877</td>
      <td>1250</td>
    </tr>
    <tr>
      <th>2346</th>
      <td>666050758794694657</td>
      <td>60</td>
      <td>136</td>
    </tr>
    <tr>
      <th>2347</th>
      <td>666049248165822465</td>
      <td>41</td>
      <td>111</td>
    </tr>
    <tr>
      <th>2348</th>
      <td>666044226329800704</td>
      <td>147</td>
      <td>309</td>
    </tr>
    <tr>
      <th>2349</th>
      <td>666033412701032449</td>
      <td>47</td>
      <td>128</td>
    </tr>
    <tr>
      <th>2350</th>
      <td>666029285002620928</td>
      <td>48</td>
      <td>132</td>
    </tr>
    <tr>
      <th>2351</th>
      <td>666020888022790149</td>
      <td>530</td>
      <td>2528</td>
    </tr>
  </tbody>
</table>
<p>2352 rows × 3 columns</p>
</div>




```python
df_json.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2352 entries, 0 to 2351
    Data columns (total 3 columns):
    tweet_id          2352 non-null object
    retweet_count     2352 non-null object
    favorite_count    2352 non-null object
    dtypes: object(3)
    memory usage: 55.2+ KB


- **转帖数和喜爱数的类型应为int64**（Q）

## 问题汇总：

#### 数据完整性问题
##### df_twitter
* Done C1_缺失`retweeted_count` 和 `favorite_count` 需要从`df_json`文件中提取增加
* Done C2_狗的品种缺失需要从`df_pred`中提取补全

#### 数据质量问题
##### df_twitter
* Done Q1_部分`name`列信息缺失，需要补全狗的名字，同时部分狗的名字提取不正确
* Done Q2_`tweet_id`的类型为int64，`in_reply_to_status_id` & `in_reply_to_user_id` 的类型为64位浮点，实际上这列不需要进行计算，我们需要将所有的ID列都转化为字符串格式
* Done Q3_`timestamp`时间戳的数据格式为object，应当转换为timedate
* Done Q4_狗的地位有重复标注现象，需要进行更正
* Done Q5_部分Rating评分的分值不正确
* Done Q6_为了后续统计分析不受影响，所有缺失的数据应该被标记为np.nan的逻辑形式，而不是'None'的字符串形式
* Done Q7_根据项目要求转发的数据以及没有图片的数据都不包含在内***（update_20180403）***

##### df_pred
* Done Q7_`tweet_id` 和 `img_num`的类型为int64，实际上这列不需要进行计算，我们需要将这两列都转化为字符串格式

##### df_json
* Done Q8_`retweet_count`&`favorite_count`的类型应为int64

#### 数据整洁度问题
##### df_twitter
* Done T1_`source`,`expanded_urls`,`in_reply_to_status_id`,`in_reply_to_user_id`,`retweeted_status_id`,`retweeted_status_user_id`,`retweeted_status_timestamp`列的信息没有用，需要删除
* Done T2_狗的地位用了四列，应该合为一列



# 清洗数据
## 添加缺失数据 & 清理无用数据

### 定义
C1_缺失`retweeted_count` 和 `favorite_count` 需要从`df_json`文件中提取增加

### 代码


```python
df_twitter_clean = pd.merge(df_twitter, df_json, how='left', on='tweet_id')
```

### 测试


```python
df_twitter_clean.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 2356 entries, 0 to 2355
    Data columns (total 19 columns):
    tweet_id                      2356 non-null object
    in_reply_to_status_id         78 non-null float64
    in_reply_to_user_id           78 non-null float64
    timestamp                     2356 non-null object
    source                        2356 non-null object
    text                          2356 non-null object
    retweeted_status_id           181 non-null float64
    retweeted_status_user_id      181 non-null float64
    retweeted_status_timestamp    181 non-null object
    expanded_urls                 2297 non-null object
    rating_numerator              2356 non-null int64
    rating_denominator            2356 non-null int64
    name                          2356 non-null object
    doggo                         2356 non-null object
    floofer                       2356 non-null object
    pupper                        2356 non-null object
    puppo                         2356 non-null object
    retweet_count                 2352 non-null object
    favorite_count                2352 non-null object
    dtypes: float64(4), int64(2), object(13)
    memory usage: 368.1+ KB


### 定义
* Done Q7_根据项目要求转发的数据以及没有图片的数据都不包含在内***（update_20180403）***

### 代码


```python
df_twitter_clean = df_twitter_clean.drop(df_twitter_clean[df_twitter_clean['retweeted_status_id'] > 0].index, axis = 0)
```


```python
df_twitter_clean.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 2175 entries, 0 to 2355
    Data columns (total 19 columns):
    tweet_id                      2175 non-null object
    in_reply_to_status_id         78 non-null float64
    in_reply_to_user_id           78 non-null float64
    timestamp                     2175 non-null object
    source                        2175 non-null object
    text                          2175 non-null object
    retweeted_status_id           0 non-null float64
    retweeted_status_user_id      0 non-null float64
    retweeted_status_timestamp    0 non-null object
    expanded_urls                 2117 non-null object
    rating_numerator              2175 non-null int64
    rating_denominator            2175 non-null int64
    name                          2175 non-null object
    doggo                         2175 non-null object
    floofer                       2175 non-null object
    pupper                        2175 non-null object
    puppo                         2175 non-null object
    retweet_count                 2175 non-null object
    favorite_count                2175 non-null object
    dtypes: float64(4), int64(2), object(13)
    memory usage: 339.8+ KB


### 定义
 T1_`source`,`expanded_urls`,`in_reply_to_status_id`,`in_reply_to_user_id`,`retweeted_status_id`,`retweeted_status_user_id`,`retweeted_status_timestamp`列的信息没有用，需要删除

### 代码


```python
df_twitter_clean.drop(['source','expanded_urls','in_reply_to_status_id', 'in_reply_to_user_id', 'retweeted_status_id','retweeted_status_user_id', 'retweeted_status_timestamp'], axis = 1, inplace = True)
```

### 测试


```python
df_twitter_clean.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 2175 entries, 0 to 2355
    Data columns (total 12 columns):
    tweet_id              2175 non-null object
    timestamp             2175 non-null object
    text                  2175 non-null object
    rating_numerator      2175 non-null int64
    rating_denominator    2175 non-null int64
    name                  2175 non-null object
    doggo                 2175 non-null object
    floofer               2175 non-null object
    pupper                2175 non-null object
    puppo                 2175 non-null object
    retweet_count         2175 non-null object
    favorite_count        2175 non-null object
    dtypes: int64(2), object(10)
    memory usage: 220.9+ KB


### 定义
C2_狗的品种缺失预测需要从df_pred中提取补全

Q7_根据项目要求转发的数据以及没有图片的数据都不包含在内***（update_20180403）***

### 代码


```python
df_pred_clean = df_pred.copy()
df_pred_clean.drop(['jpg_url','img_num'],axis = 1, inplace = True)
df_twitter_clean = pd.merge(df_twitter_clean, df_pred_clean)#20180403更新了merge的方法，以删除没有图片的数据部分
```

### 测试


```python
df_twitter_clean.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 1994 entries, 0 to 1993
    Data columns (total 21 columns):
    tweet_id              1994 non-null object
    timestamp             1994 non-null object
    text                  1994 non-null object
    rating_numerator      1994 non-null int64
    rating_denominator    1994 non-null int64
    name                  1994 non-null object
    doggo                 1994 non-null object
    floofer               1994 non-null object
    pupper                1994 non-null object
    puppo                 1994 non-null object
    retweet_count         1994 non-null object
    favorite_count        1994 non-null object
    p1                    1994 non-null object
    p1_conf               1994 non-null float64
    p1_dog                1994 non-null bool
    p2                    1994 non-null object
    p2_conf               1994 non-null float64
    p2_dog                1994 non-null bool
    p3                    1994 non-null object
    p3_conf               1994 non-null float64
    p3_dog                1994 non-null bool
    dtypes: bool(3), float64(3), int64(2), object(13)
    memory usage: 301.8+ KB


### 定义
T2_狗的地位用了四列，应该合为一列

Q4_狗的地位有重复标注现象，需要进行更正

Update_20180403_text中字符转化成小写后再提取

### 代码


```python
#扫描text文档，填充狗的地位
df_twitter_clean['type'] = 'None'
dog_lists = ['pupper', 'puppo', 'doggo', 'floofer']
for i in range(0,len(df_twitter_clean)):
    text = df_twitter_clean.text[i].lower()#20180403将text文字转化小写后在进行提取
    for dog_status in dog_lists:
        if dog_status in text:
            df_twitter_clean.type[i] = dog_status
df_twitter_clean
```

    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:8: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      





<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>timestamp</th>
      <th>text</th>
      <th>rating_numerator</th>
      <th>rating_denominator</th>
      <th>name</th>
      <th>doggo</th>
      <th>floofer</th>
      <th>pupper</th>
      <th>puppo</th>
      <th>...</th>
      <th>p1</th>
      <th>p1_conf</th>
      <th>p1_dog</th>
      <th>p2</th>
      <th>p2_conf</th>
      <th>p2_dog</th>
      <th>p3</th>
      <th>p3_conf</th>
      <th>p3_dog</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>892420643555336193</td>
      <td>2017-08-01 16:23:56 +0000</td>
      <td>This is Phineas. He's a mystical boy. Only eve...</td>
      <td>13</td>
      <td>10</td>
      <td>Phineas</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>orange</td>
      <td>0.097049</td>
      <td>False</td>
      <td>bagel</td>
      <td>0.085851</td>
      <td>False</td>
      <td>banana</td>
      <td>0.076110</td>
      <td>False</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1</th>
      <td>892177421306343426</td>
      <td>2017-08-01 00:17:27 +0000</td>
      <td>This is Tilly. She's just checking pup on you....</td>
      <td>13</td>
      <td>10</td>
      <td>Tilly</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Chihuahua</td>
      <td>0.323581</td>
      <td>True</td>
      <td>Pekinese</td>
      <td>0.090647</td>
      <td>True</td>
      <td>papillon</td>
      <td>0.068957</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>2</th>
      <td>891815181378084864</td>
      <td>2017-07-31 00:18:03 +0000</td>
      <td>This is Archie. He is a rare Norwegian Pouncin...</td>
      <td>12</td>
      <td>10</td>
      <td>Archie</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Chihuahua</td>
      <td>0.716012</td>
      <td>True</td>
      <td>malamute</td>
      <td>0.078253</td>
      <td>True</td>
      <td>kelpie</td>
      <td>0.031379</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>3</th>
      <td>891689557279858688</td>
      <td>2017-07-30 15:58:51 +0000</td>
      <td>This is Darla. She commenced a snooze mid meal...</td>
      <td>13</td>
      <td>10</td>
      <td>Darla</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>paper_towel</td>
      <td>0.170278</td>
      <td>False</td>
      <td>Labrador_retriever</td>
      <td>0.168086</td>
      <td>True</td>
      <td>spatula</td>
      <td>0.040836</td>
      <td>False</td>
      <td>None</td>
    </tr>
    <tr>
      <th>4</th>
      <td>891327558926688256</td>
      <td>2017-07-29 16:00:24 +0000</td>
      <td>This is Franklin. He would like you to stop ca...</td>
      <td>12</td>
      <td>10</td>
      <td>Franklin</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>basset</td>
      <td>0.555712</td>
      <td>True</td>
      <td>English_springer</td>
      <td>0.225770</td>
      <td>True</td>
      <td>German_short-haired_pointer</td>
      <td>0.175219</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>5</th>
      <td>891087950875897856</td>
      <td>2017-07-29 00:08:17 +0000</td>
      <td>Here we have a majestic great white breaching ...</td>
      <td>13</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Chesapeake_Bay_retriever</td>
      <td>0.425595</td>
      <td>True</td>
      <td>Irish_terrier</td>
      <td>0.116317</td>
      <td>True</td>
      <td>Indian_elephant</td>
      <td>0.076902</td>
      <td>False</td>
      <td>None</td>
    </tr>
    <tr>
      <th>6</th>
      <td>890971913173991426</td>
      <td>2017-07-28 16:27:12 +0000</td>
      <td>Meet Jax. He enjoys ice cream so much he gets ...</td>
      <td>13</td>
      <td>10</td>
      <td>Jax</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Appenzeller</td>
      <td>0.341703</td>
      <td>True</td>
      <td>Border_collie</td>
      <td>0.199287</td>
      <td>True</td>
      <td>ice_lolly</td>
      <td>0.193548</td>
      <td>False</td>
      <td>None</td>
    </tr>
    <tr>
      <th>7</th>
      <td>890729181411237888</td>
      <td>2017-07-28 00:22:40 +0000</td>
      <td>When you watch your owner call another dog a g...</td>
      <td>13</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Pomeranian</td>
      <td>0.566142</td>
      <td>True</td>
      <td>Eskimo_dog</td>
      <td>0.178406</td>
      <td>True</td>
      <td>Pembroke</td>
      <td>0.076507</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>8</th>
      <td>890609185150312448</td>
      <td>2017-07-27 16:25:51 +0000</td>
      <td>This is Zoey. She doesn't want to be one of th...</td>
      <td>13</td>
      <td>10</td>
      <td>Zoey</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Irish_terrier</td>
      <td>0.487574</td>
      <td>True</td>
      <td>Irish_setter</td>
      <td>0.193054</td>
      <td>True</td>
      <td>Chesapeake_Bay_retriever</td>
      <td>0.118184</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>9</th>
      <td>890240255349198849</td>
      <td>2017-07-26 15:59:51 +0000</td>
      <td>This is Cassie. She is a college pup. Studying...</td>
      <td>14</td>
      <td>10</td>
      <td>Cassie</td>
      <td>doggo</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Pembroke</td>
      <td>0.511319</td>
      <td>True</td>
      <td>Cardigan</td>
      <td>0.451038</td>
      <td>True</td>
      <td>Chihuahua</td>
      <td>0.029248</td>
      <td>True</td>
      <td>doggo</td>
    </tr>
    <tr>
      <th>10</th>
      <td>890006608113172480</td>
      <td>2017-07-26 00:31:25 +0000</td>
      <td>This is Koda. He is a South Australian decksha...</td>
      <td>13</td>
      <td>10</td>
      <td>Koda</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Samoyed</td>
      <td>0.957979</td>
      <td>True</td>
      <td>Pomeranian</td>
      <td>0.013884</td>
      <td>True</td>
      <td>chow</td>
      <td>0.008167</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>11</th>
      <td>889880896479866881</td>
      <td>2017-07-25 16:11:53 +0000</td>
      <td>This is Bruno. He is a service shark. Only get...</td>
      <td>13</td>
      <td>10</td>
      <td>Bruno</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>French_bulldog</td>
      <td>0.377417</td>
      <td>True</td>
      <td>Labrador_retriever</td>
      <td>0.151317</td>
      <td>True</td>
      <td>muzzle</td>
      <td>0.082981</td>
      <td>False</td>
      <td>None</td>
    </tr>
    <tr>
      <th>12</th>
      <td>889665388333682689</td>
      <td>2017-07-25 01:55:32 +0000</td>
      <td>Here's a puppo that seems to be on the fence a...</td>
      <td>13</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>puppo</td>
      <td>...</td>
      <td>Pembroke</td>
      <td>0.966327</td>
      <td>True</td>
      <td>Cardigan</td>
      <td>0.027356</td>
      <td>True</td>
      <td>basenji</td>
      <td>0.004633</td>
      <td>True</td>
      <td>puppo</td>
    </tr>
    <tr>
      <th>13</th>
      <td>889638837579907072</td>
      <td>2017-07-25 00:10:02 +0000</td>
      <td>This is Ted. He does his best. Sometimes that'...</td>
      <td>12</td>
      <td>10</td>
      <td>Ted</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>French_bulldog</td>
      <td>0.991650</td>
      <td>True</td>
      <td>boxer</td>
      <td>0.002129</td>
      <td>True</td>
      <td>Staffordshire_bullterrier</td>
      <td>0.001498</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>14</th>
      <td>889531135344209921</td>
      <td>2017-07-24 17:02:04 +0000</td>
      <td>This is Stuart. He's sporting his favorite fan...</td>
      <td>13</td>
      <td>10</td>
      <td>Stuart</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>puppo</td>
      <td>...</td>
      <td>golden_retriever</td>
      <td>0.953442</td>
      <td>True</td>
      <td>Labrador_retriever</td>
      <td>0.013834</td>
      <td>True</td>
      <td>redbone</td>
      <td>0.007958</td>
      <td>True</td>
      <td>puppo</td>
    </tr>
    <tr>
      <th>15</th>
      <td>889278841981685760</td>
      <td>2017-07-24 00:19:32 +0000</td>
      <td>This is Oliver. You're witnessing one of his m...</td>
      <td>13</td>
      <td>10</td>
      <td>Oliver</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>whippet</td>
      <td>0.626152</td>
      <td>True</td>
      <td>borzoi</td>
      <td>0.194742</td>
      <td>True</td>
      <td>Saluki</td>
      <td>0.027351</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>16</th>
      <td>888917238123831296</td>
      <td>2017-07-23 00:22:39 +0000</td>
      <td>This is Jim. He found a fren. Taught him how t...</td>
      <td>12</td>
      <td>10</td>
      <td>Jim</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>golden_retriever</td>
      <td>0.714719</td>
      <td>True</td>
      <td>Tibetan_mastiff</td>
      <td>0.120184</td>
      <td>True</td>
      <td>Labrador_retriever</td>
      <td>0.105506</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>17</th>
      <td>888804989199671297</td>
      <td>2017-07-22 16:56:37 +0000</td>
      <td>This is Zeke. He has a new stick. Very proud o...</td>
      <td>13</td>
      <td>10</td>
      <td>Zeke</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>golden_retriever</td>
      <td>0.469760</td>
      <td>True</td>
      <td>Labrador_retriever</td>
      <td>0.184172</td>
      <td>True</td>
      <td>English_setter</td>
      <td>0.073482</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>18</th>
      <td>888554962724278272</td>
      <td>2017-07-22 00:23:06 +0000</td>
      <td>This is Ralphus. He's powering up. Attempting ...</td>
      <td>13</td>
      <td>10</td>
      <td>Ralphus</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Siberian_husky</td>
      <td>0.700377</td>
      <td>True</td>
      <td>Eskimo_dog</td>
      <td>0.166511</td>
      <td>True</td>
      <td>malamute</td>
      <td>0.111411</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>19</th>
      <td>888078434458587136</td>
      <td>2017-07-20 16:49:33 +0000</td>
      <td>This is Gerald. He was just told he didn't get...</td>
      <td>12</td>
      <td>10</td>
      <td>Gerald</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>French_bulldog</td>
      <td>0.995026</td>
      <td>True</td>
      <td>pug</td>
      <td>0.000932</td>
      <td>True</td>
      <td>bull_mastiff</td>
      <td>0.000903</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>20</th>
      <td>887705289381826560</td>
      <td>2017-07-19 16:06:48 +0000</td>
      <td>This is Jeffrey. He has a monopoly on the pool...</td>
      <td>13</td>
      <td>10</td>
      <td>Jeffrey</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>basset</td>
      <td>0.821664</td>
      <td>True</td>
      <td>redbone</td>
      <td>0.087582</td>
      <td>True</td>
      <td>Weimaraner</td>
      <td>0.026236</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>21</th>
      <td>887517139158093824</td>
      <td>2017-07-19 03:39:09 +0000</td>
      <td>I've yet to rate a Venezuelan Hover Wiener. Th...</td>
      <td>14</td>
      <td>10</td>
      <td>such</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>limousine</td>
      <td>0.130432</td>
      <td>False</td>
      <td>tow_truck</td>
      <td>0.029175</td>
      <td>False</td>
      <td>shopping_cart</td>
      <td>0.026321</td>
      <td>False</td>
      <td>None</td>
    </tr>
    <tr>
      <th>22</th>
      <td>887473957103951883</td>
      <td>2017-07-19 00:47:34 +0000</td>
      <td>This is Canela. She attempted some fancy porch...</td>
      <td>13</td>
      <td>10</td>
      <td>Canela</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Pembroke</td>
      <td>0.809197</td>
      <td>True</td>
      <td>Rhodesian_ridgeback</td>
      <td>0.054950</td>
      <td>True</td>
      <td>beagle</td>
      <td>0.038915</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>23</th>
      <td>887343217045368832</td>
      <td>2017-07-18 16:08:03 +0000</td>
      <td>You may not have known you needed to see this ...</td>
      <td>13</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Mexican_hairless</td>
      <td>0.330741</td>
      <td>True</td>
      <td>sea_lion</td>
      <td>0.275645</td>
      <td>False</td>
      <td>Weimaraner</td>
      <td>0.134203</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>24</th>
      <td>887101392804085760</td>
      <td>2017-07-18 00:07:08 +0000</td>
      <td>This... is a Jubilant Antarctic House Bear. We...</td>
      <td>12</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Samoyed</td>
      <td>0.733942</td>
      <td>True</td>
      <td>Eskimo_dog</td>
      <td>0.035029</td>
      <td>True</td>
      <td>Staffordshire_bullterrier</td>
      <td>0.029705</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>25</th>
      <td>886983233522544640</td>
      <td>2017-07-17 16:17:36 +0000</td>
      <td>This is Maya. She's very shy. Rarely leaves he...</td>
      <td>13</td>
      <td>10</td>
      <td>Maya</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Chihuahua</td>
      <td>0.793469</td>
      <td>True</td>
      <td>toy_terrier</td>
      <td>0.143528</td>
      <td>True</td>
      <td>can_opener</td>
      <td>0.032253</td>
      <td>False</td>
      <td>None</td>
    </tr>
    <tr>
      <th>26</th>
      <td>886736880519319552</td>
      <td>2017-07-16 23:58:41 +0000</td>
      <td>This is Mingus. He's a wonderful father to his...</td>
      <td>13</td>
      <td>10</td>
      <td>Mingus</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>kuvasz</td>
      <td>0.309706</td>
      <td>True</td>
      <td>Great_Pyrenees</td>
      <td>0.186136</td>
      <td>True</td>
      <td>Dandie_Dinmont</td>
      <td>0.086346</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>27</th>
      <td>886680336477933568</td>
      <td>2017-07-16 20:14:00 +0000</td>
      <td>This is Derek. He's late for a dog meeting. 13...</td>
      <td>13</td>
      <td>10</td>
      <td>Derek</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>convertible</td>
      <td>0.738995</td>
      <td>False</td>
      <td>sports_car</td>
      <td>0.139952</td>
      <td>False</td>
      <td>car_wheel</td>
      <td>0.044173</td>
      <td>False</td>
      <td>None</td>
    </tr>
    <tr>
      <th>28</th>
      <td>886366144734445568</td>
      <td>2017-07-15 23:25:31 +0000</td>
      <td>This is Roscoe. Another pupper fallen victim t...</td>
      <td>12</td>
      <td>10</td>
      <td>Roscoe</td>
      <td>None</td>
      <td>None</td>
      <td>pupper</td>
      <td>None</td>
      <td>...</td>
      <td>French_bulldog</td>
      <td>0.999201</td>
      <td>True</td>
      <td>Chihuahua</td>
      <td>0.000361</td>
      <td>True</td>
      <td>Boston_bull</td>
      <td>0.000076</td>
      <td>True</td>
      <td>pupper</td>
    </tr>
    <tr>
      <th>29</th>
      <td>886258384151887873</td>
      <td>2017-07-15 16:17:19 +0000</td>
      <td>This is Waffles. His doggles are pupside down....</td>
      <td>13</td>
      <td>10</td>
      <td>Waffles</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>pug</td>
      <td>0.943575</td>
      <td>True</td>
      <td>shower_cap</td>
      <td>0.025286</td>
      <td>False</td>
      <td>Siamese_cat</td>
      <td>0.002849</td>
      <td>False</td>
      <td>None</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1964</th>
      <td>666411507551481857</td>
      <td>2015-11-17 00:24:19 +0000</td>
      <td>This is quite the dog. Gets really excited whe...</td>
      <td>2</td>
      <td>10</td>
      <td>quite</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>coho</td>
      <td>0.404640</td>
      <td>False</td>
      <td>barracouta</td>
      <td>0.271485</td>
      <td>False</td>
      <td>gar</td>
      <td>0.189945</td>
      <td>False</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1965</th>
      <td>666407126856765440</td>
      <td>2015-11-17 00:06:54 +0000</td>
      <td>This is a southern Vesuvius bumblegruff. Can d...</td>
      <td>7</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>black-and-tan_coonhound</td>
      <td>0.529139</td>
      <td>True</td>
      <td>bloodhound</td>
      <td>0.244220</td>
      <td>True</td>
      <td>flat-coated_retriever</td>
      <td>0.173810</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1966</th>
      <td>666396247373291520</td>
      <td>2015-11-16 23:23:41 +0000</td>
      <td>Oh goodness. A super rare northeast Qdoba kang...</td>
      <td>9</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Chihuahua</td>
      <td>0.978108</td>
      <td>True</td>
      <td>toy_terrier</td>
      <td>0.009397</td>
      <td>True</td>
      <td>papillon</td>
      <td>0.004577</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1967</th>
      <td>666373753744588802</td>
      <td>2015-11-16 21:54:18 +0000</td>
      <td>Those are sunglasses and a jean jacket. 11/10 ...</td>
      <td>11</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>soft-coated_wheaten_terrier</td>
      <td>0.326467</td>
      <td>True</td>
      <td>Afghan_hound</td>
      <td>0.259551</td>
      <td>True</td>
      <td>briard</td>
      <td>0.206803</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1968</th>
      <td>666362758909284353</td>
      <td>2015-11-16 21:10:36 +0000</td>
      <td>Unique dog here. Very small. Lives in containe...</td>
      <td>6</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>guinea_pig</td>
      <td>0.996496</td>
      <td>False</td>
      <td>skunk</td>
      <td>0.002402</td>
      <td>False</td>
      <td>hamster</td>
      <td>0.000461</td>
      <td>False</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1969</th>
      <td>666353288456101888</td>
      <td>2015-11-16 20:32:58 +0000</td>
      <td>Here we have a mixed Asiago from the Galápagos...</td>
      <td>8</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>malamute</td>
      <td>0.336874</td>
      <td>True</td>
      <td>Siberian_husky</td>
      <td>0.147655</td>
      <td>True</td>
      <td>Eskimo_dog</td>
      <td>0.093412</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1970</th>
      <td>666345417576210432</td>
      <td>2015-11-16 20:01:42 +0000</td>
      <td>Look at this jokester thinking seat belt laws ...</td>
      <td>10</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>golden_retriever</td>
      <td>0.858744</td>
      <td>True</td>
      <td>Chesapeake_Bay_retriever</td>
      <td>0.054787</td>
      <td>True</td>
      <td>Labrador_retriever</td>
      <td>0.014241</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1971</th>
      <td>666337882303524864</td>
      <td>2015-11-16 19:31:45 +0000</td>
      <td>This is an extremely rare horned Parthenon. No...</td>
      <td>9</td>
      <td>10</td>
      <td>an</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>ox</td>
      <td>0.416669</td>
      <td>False</td>
      <td>Newfoundland</td>
      <td>0.278407</td>
      <td>True</td>
      <td>groenendael</td>
      <td>0.102643</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1972</th>
      <td>666293911632134144</td>
      <td>2015-11-16 16:37:02 +0000</td>
      <td>This is a funny dog. Weird toes. Won't come do...</td>
      <td>3</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>three-toed_sloth</td>
      <td>0.914671</td>
      <td>False</td>
      <td>otter</td>
      <td>0.015250</td>
      <td>False</td>
      <td>great_grey_owl</td>
      <td>0.013207</td>
      <td>False</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1973</th>
      <td>666287406224695296</td>
      <td>2015-11-16 16:11:11 +0000</td>
      <td>This is an Albanian 3 1/2 legged  Episcopalian...</td>
      <td>1</td>
      <td>2</td>
      <td>an</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Maltese_dog</td>
      <td>0.857531</td>
      <td>True</td>
      <td>toy_poodle</td>
      <td>0.063064</td>
      <td>True</td>
      <td>miniature_poodle</td>
      <td>0.025581</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1974</th>
      <td>666273097616637952</td>
      <td>2015-11-16 15:14:19 +0000</td>
      <td>Can take selfies 11/10 https://t.co/ws2AMaNwPW</td>
      <td>11</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Italian_greyhound</td>
      <td>0.176053</td>
      <td>True</td>
      <td>toy_terrier</td>
      <td>0.111884</td>
      <td>True</td>
      <td>basenji</td>
      <td>0.111152</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1975</th>
      <td>666268910803644416</td>
      <td>2015-11-16 14:57:41 +0000</td>
      <td>Very concerned about fellow dog trapped in com...</td>
      <td>10</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>desktop_computer</td>
      <td>0.086502</td>
      <td>False</td>
      <td>desk</td>
      <td>0.085547</td>
      <td>False</td>
      <td>bookcase</td>
      <td>0.079480</td>
      <td>False</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1976</th>
      <td>666104133288665088</td>
      <td>2015-11-16 04:02:55 +0000</td>
      <td>Not familiar with this breed. No tail (weird)....</td>
      <td>1</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>hen</td>
      <td>0.965932</td>
      <td>False</td>
      <td>cock</td>
      <td>0.033919</td>
      <td>False</td>
      <td>partridge</td>
      <td>0.000052</td>
      <td>False</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1977</th>
      <td>666102155909144576</td>
      <td>2015-11-16 03:55:04 +0000</td>
      <td>Oh my. Here you are seeing an Adobe Setter giv...</td>
      <td>11</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>English_setter</td>
      <td>0.298617</td>
      <td>True</td>
      <td>Newfoundland</td>
      <td>0.149842</td>
      <td>True</td>
      <td>borzoi</td>
      <td>0.133649</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1978</th>
      <td>666099513787052032</td>
      <td>2015-11-16 03:44:34 +0000</td>
      <td>Can stand on stump for what seems like a while...</td>
      <td>8</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Lhasa</td>
      <td>0.582330</td>
      <td>True</td>
      <td>Shih-Tzu</td>
      <td>0.166192</td>
      <td>True</td>
      <td>Dandie_Dinmont</td>
      <td>0.089688</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1979</th>
      <td>666094000022159362</td>
      <td>2015-11-16 03:22:39 +0000</td>
      <td>This appears to be a Mongolian Presbyterian mi...</td>
      <td>9</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>bloodhound</td>
      <td>0.195217</td>
      <td>True</td>
      <td>German_shepherd</td>
      <td>0.078260</td>
      <td>True</td>
      <td>malinois</td>
      <td>0.075628</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1980</th>
      <td>666082916733198337</td>
      <td>2015-11-16 02:38:37 +0000</td>
      <td>Here we have a well-established sunblockerspan...</td>
      <td>6</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>pug</td>
      <td>0.489814</td>
      <td>True</td>
      <td>bull_mastiff</td>
      <td>0.404722</td>
      <td>True</td>
      <td>French_bulldog</td>
      <td>0.048960</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1981</th>
      <td>666073100786774016</td>
      <td>2015-11-16 01:59:36 +0000</td>
      <td>Let's hope this flight isn't Malaysian (lol). ...</td>
      <td>10</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Walker_hound</td>
      <td>0.260857</td>
      <td>True</td>
      <td>English_foxhound</td>
      <td>0.175382</td>
      <td>True</td>
      <td>Ibizan_hound</td>
      <td>0.097471</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1982</th>
      <td>666071193221509120</td>
      <td>2015-11-16 01:52:02 +0000</td>
      <td>Here we have a northern speckled Rhododendron....</td>
      <td>9</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Gordon_setter</td>
      <td>0.503672</td>
      <td>True</td>
      <td>Yorkshire_terrier</td>
      <td>0.174201</td>
      <td>True</td>
      <td>Pekinese</td>
      <td>0.109454</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1983</th>
      <td>666063827256086533</td>
      <td>2015-11-16 01:22:45 +0000</td>
      <td>This is the happiest dog you will ever see. Ve...</td>
      <td>10</td>
      <td>10</td>
      <td>the</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>golden_retriever</td>
      <td>0.775930</td>
      <td>True</td>
      <td>Tibetan_mastiff</td>
      <td>0.093718</td>
      <td>True</td>
      <td>Labrador_retriever</td>
      <td>0.072427</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1984</th>
      <td>666058600524156928</td>
      <td>2015-11-16 01:01:59 +0000</td>
      <td>Here is the Rand Paul of retrievers folks! He'...</td>
      <td>8</td>
      <td>10</td>
      <td>the</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>miniature_poodle</td>
      <td>0.201493</td>
      <td>True</td>
      <td>komondor</td>
      <td>0.192305</td>
      <td>True</td>
      <td>soft-coated_wheaten_terrier</td>
      <td>0.082086</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1985</th>
      <td>666057090499244032</td>
      <td>2015-11-16 00:55:59 +0000</td>
      <td>My oh my. This is a rare blond Canadian terrie...</td>
      <td>9</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>shopping_cart</td>
      <td>0.962465</td>
      <td>False</td>
      <td>shopping_basket</td>
      <td>0.014594</td>
      <td>False</td>
      <td>golden_retriever</td>
      <td>0.007959</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1986</th>
      <td>666055525042405380</td>
      <td>2015-11-16 00:49:46 +0000</td>
      <td>Here is a Siberian heavily armored polar bear ...</td>
      <td>10</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>chow</td>
      <td>0.692517</td>
      <td>True</td>
      <td>Tibetan_mastiff</td>
      <td>0.058279</td>
      <td>True</td>
      <td>fur_coat</td>
      <td>0.054449</td>
      <td>False</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1987</th>
      <td>666051853826850816</td>
      <td>2015-11-16 00:35:11 +0000</td>
      <td>This is an odd dog. Hard on the outside but lo...</td>
      <td>2</td>
      <td>10</td>
      <td>an</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>box_turtle</td>
      <td>0.933012</td>
      <td>False</td>
      <td>mud_turtle</td>
      <td>0.045885</td>
      <td>False</td>
      <td>terrapin</td>
      <td>0.017885</td>
      <td>False</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1988</th>
      <td>666050758794694657</td>
      <td>2015-11-16 00:30:50 +0000</td>
      <td>This is a truly beautiful English Wilson Staff...</td>
      <td>10</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Bernese_mountain_dog</td>
      <td>0.651137</td>
      <td>True</td>
      <td>English_springer</td>
      <td>0.263788</td>
      <td>True</td>
      <td>Greater_Swiss_Mountain_dog</td>
      <td>0.016199</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1989</th>
      <td>666049248165822465</td>
      <td>2015-11-16 00:24:50 +0000</td>
      <td>Here we have a 1949 1st generation vulpix. Enj...</td>
      <td>5</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>miniature_pinscher</td>
      <td>0.560311</td>
      <td>True</td>
      <td>Rottweiler</td>
      <td>0.243682</td>
      <td>True</td>
      <td>Doberman</td>
      <td>0.154629</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1990</th>
      <td>666044226329800704</td>
      <td>2015-11-16 00:04:52 +0000</td>
      <td>This is a purebred Piers Morgan. Loves to Netf...</td>
      <td>6</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Rhodesian_ridgeback</td>
      <td>0.408143</td>
      <td>True</td>
      <td>redbone</td>
      <td>0.360687</td>
      <td>True</td>
      <td>miniature_pinscher</td>
      <td>0.222752</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1991</th>
      <td>666033412701032449</td>
      <td>2015-11-15 23:21:54 +0000</td>
      <td>Here is a very happy pup. Big fan of well-main...</td>
      <td>9</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>German_shepherd</td>
      <td>0.596461</td>
      <td>True</td>
      <td>malinois</td>
      <td>0.138584</td>
      <td>True</td>
      <td>bloodhound</td>
      <td>0.116197</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1992</th>
      <td>666029285002620928</td>
      <td>2015-11-15 23:05:30 +0000</td>
      <td>This is a western brown Mitsubishi terrier. Up...</td>
      <td>7</td>
      <td>10</td>
      <td>a</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>redbone</td>
      <td>0.506826</td>
      <td>True</td>
      <td>miniature_pinscher</td>
      <td>0.074192</td>
      <td>True</td>
      <td>Rhodesian_ridgeback</td>
      <td>0.072010</td>
      <td>True</td>
      <td>None</td>
    </tr>
    <tr>
      <th>1993</th>
      <td>666020888022790149</td>
      <td>2015-11-15 22:32:08 +0000</td>
      <td>Here we have a Japanese Irish Setter. Lost eye...</td>
      <td>8</td>
      <td>10</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>...</td>
      <td>Welsh_springer_spaniel</td>
      <td>0.465074</td>
      <td>True</td>
      <td>collie</td>
      <td>0.156665</td>
      <td>True</td>
      <td>Shetland_sheepdog</td>
      <td>0.061428</td>
      <td>True</td>
      <td>None</td>
    </tr>
  </tbody>
</table>
<p>1994 rows × 22 columns</p>
</div>




```python
none_list = df_twitter_clean['tweet_id'][(df_twitter_clean.doggo == 'None') & (df_twitter_clean.floofer == 'None') & (df_twitter_clean.pupper == 'None') & (df_twitter_clean.puppo =='None')]
none_dog_list = list(none_list)
len(none_dog_list)
```




    1688




```python
#筛选出有重复标记的数据段
with pd.option_context('max_colwidth', 200):
    display(df_twitter_clean[df_twitter_clean['tweet_id'].isin(dupl_dog_list)][['tweet_id','name','text','doggo','floofer','pupper','puppo']])
```


<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>name</th>
      <th>text</th>
      <th>doggo</th>
      <th>floofer</th>
      <th>pupper</th>
      <th>puppo</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>148</th>
      <td>855851453814013952</td>
      <td>None</td>
      <td>Here's a puppo participating in the #ScienceMarch. Cleverly disguising her own doggo agenda. 13/10 would keep the planet habitable for https://t.co/cMhq16isel</td>
      <td>doggo</td>
      <td>None</td>
      <td>None</td>
      <td>puppo</td>
    </tr>
    <tr>
      <th>154</th>
      <td>854010172552949760</td>
      <td>None</td>
      <td>At first I thought this was a shy doggo, but it's actually a Rare Canadian Floofer Owl. Amateurs would confuse the two. 11/10 only send dogs https://t.co/TXdT3tmuYk</td>
      <td>doggo</td>
      <td>floofer</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>340</th>
      <td>817777686764523521</td>
      <td>Dido</td>
      <td>This is Dido. She's playing the lead role in "Pupper Stops to Catch Snow Before Resuming Shadow Box with Dried Apple." 13/10 (IG: didodoggo) https://t.co/m7isZrOBX7</td>
      <td>doggo</td>
      <td>None</td>
      <td>pupper</td>
      <td>None</td>
    </tr>
    <tr>
      <th>397</th>
      <td>808106460588765185</td>
      <td>None</td>
      <td>Here we have Burke (pupper) and Dexter (doggo). Pupper wants to be exactly like doggo. Both 12/10 would pet at same time https://t.co/ANBpEYHaho</td>
      <td>doggo</td>
      <td>None</td>
      <td>pupper</td>
      <td>None</td>
    </tr>
    <tr>
      <th>419</th>
      <td>802265048156610565</td>
      <td>None</td>
      <td>Like doggo, like pupper version 2. Both 11/10 https://t.co/9IxWAXFqze</td>
      <td>doggo</td>
      <td>None</td>
      <td>pupper</td>
      <td>None</td>
    </tr>
    <tr>
      <th>425</th>
      <td>801115127852503040</td>
      <td>Bones</td>
      <td>This is Bones. He's being haunted by another doggo of roughly the same size. 12/10 deep breaths pupper everything's fine https://t.co/55Dqe0SJNj</td>
      <td>doggo</td>
      <td>None</td>
      <td>pupper</td>
      <td>None</td>
    </tr>
    <tr>
      <th>510</th>
      <td>785639753186217984</td>
      <td>Pinot</td>
      <td>This is Pinot. He's a sophisticated doggo. You can tell by the hat. Also pointier than your average pupper. Still 10/10 would pet cautiously https://t.co/f2wmLZTPHd</td>
      <td>doggo</td>
      <td>None</td>
      <td>pupper</td>
      <td>None</td>
    </tr>
    <tr>
      <th>652</th>
      <td>759793422261743616</td>
      <td>Maggie</td>
      <td>Meet Maggie &amp;amp; Lila. Maggie is the doggo, Lila is the pupper. They are sisters. Both 12/10 would pet at the same time https://t.co/MYwR4DQKll</td>
      <td>doggo</td>
      <td>None</td>
      <td>pupper</td>
      <td>None</td>
    </tr>
    <tr>
      <th>704</th>
      <td>751583847268179968</td>
      <td>None</td>
      <td>Please stop sending it pictures that don't even have a doggo or pupper in them. Churlish af. 5/10 neat couch tho https://t.co/u2c9c7qSg8</td>
      <td>doggo</td>
      <td>None</td>
      <td>pupper</td>
      <td>None</td>
    </tr>
    <tr>
      <th>795</th>
      <td>741067306818797568</td>
      <td>just</td>
      <td>This is just downright precious af. 12/10 for both pupper and doggo https://t.co/o5J479bZUC</td>
      <td>doggo</td>
      <td>None</td>
      <td>pupper</td>
      <td>None</td>
    </tr>
    <tr>
      <th>841</th>
      <td>733109485275860992</td>
      <td>None</td>
      <td>Like father (doggo), like son (pupper). Both 12/10 https://t.co/pG2inLaOda</td>
      <td>doggo</td>
      <td>None</td>
      <td>pupper</td>
      <td>None</td>
    </tr>
  </tbody>
</table>
</div>



```python
#with pd.option_context('max_colwidth', 200):
    #display(df_twitter_clean[df_twitter_clean['tweet_id'].isin(none_dog_list)][['tweet_id','text','doggo','floofer','pupper','puppo']])
```


```python
#df_twitter_clean[df_twitter_clean['tweet_id'].isin(dupl_dog_list)].index
```


```python
with pd.option_context('max_colwidth', 200):
    display(df_pred[df_pred['tweet_id'].isin(dupl_dog_list)][['tweet_id','jpg_url','p1_dog','p2_dog','p3_dog']])
```


<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>jpg_url</th>
      <th>p1_dog</th>
      <th>p2_dog</th>
      <th>p3_dog</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1155</th>
      <td>733109485275860992</td>
      <td>https://pbs.twimg.com/media/CiyHLocU4AI2pJu.jpg</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1201</th>
      <td>741067306818797568</td>
      <td>https://pbs.twimg.com/media/CkjMx99UoAM2B1a.jpg</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1292</th>
      <td>751583847268179968</td>
      <td>https://pbs.twimg.com/media/Cm4phTpWcAAgLsr.jpg</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1350</th>
      <td>759793422261743616</td>
      <td>https://pbs.twimg.com/media/CotUFZEWcAA2Pku.jpg</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1407</th>
      <td>770093767776997377</td>
      <td>https://pbs.twimg.com/media/CkjMx99UoAM2B1a.jpg</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1446</th>
      <td>775898661951791106</td>
      <td>https://pbs.twimg.com/media/CiyHLocU4AI2pJu.jpg</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1507</th>
      <td>785639753186217984</td>
      <td>https://pbs.twimg.com/media/CucnLmeWAAALOSC.jpg</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1609</th>
      <td>801115127852503040</td>
      <td>https://pbs.twimg.com/media/Cx4h7zHUsAAqaJd.jpg</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1616</th>
      <td>802265048156610565</td>
      <td>https://pbs.twimg.com/media/CyI3zXgWEAACQfB.jpg</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1644</th>
      <td>808106460588765185</td>
      <td>https://pbs.twimg.com/media/Czb4iFRXgAIUMiN.jpg</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1707</th>
      <td>817777686764523521</td>
      <td>https://pbs.twimg.com/ext_tw_video_thumb/817777588030476288/pu/img/KbuLpE4krHF4VdPf.jpg</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1913</th>
      <td>854010172552949760</td>
      <td>https://pbs.twimg.com/media/C9oNt91WAAAFSLS.jpg</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1919</th>
      <td>855851453814013952</td>
      <td>https://pbs.twimg.com/media/C-CYWrvWAAU8AXH.jpg</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
  </tbody>
</table>
</div>



```python
#根据对于text内信息的描述，以及df_pre中的图像和预测，调整更正重复标注的字段
#经过分析发现以下重复的原因有四类：
#第一类：标注提取错误：855851453814013952，854010172552949760，817777686764523521，801115127852503040，删除doggo
#第二类 标注提取错误：751583847268179968 删除pupper
#第三类：不是狗：785639753186217984，删除pupper & doggo
#第四类：两只狗，通常为亲子，存在两种地位，认为没有错误。

df_twitter_clean.loc[(df_twitter_clean.tweet_id == 855851453814013952),'doggo'] = 'None'
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 854010172552949760),'doggo'] = 'None'
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 817777686764523521),'doggo'] = 'None'
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 801115127852503040),'doggo'] = 'None'
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 751583847268179968),'pupper'] = 'None'
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 785639753186217984),('doggo','pupper')] = 'None'

with pd.option_context('max_colwidth', 200):
    display(df_twitter_clean[df_twitter_clean['tweet_id'].isin(dupl_dog_list)][['tweet_id','doggo','floofer','pupper','puppo']])
```


<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>doggo</th>
      <th>floofer</th>
      <th>pupper</th>
      <th>puppo</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>148</th>
      <td>855851453814013952</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>puppo</td>
    </tr>
    <tr>
      <th>154</th>
      <td>854010172552949760</td>
      <td>None</td>
      <td>floofer</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>340</th>
      <td>817777686764523521</td>
      <td>None</td>
      <td>None</td>
      <td>pupper</td>
      <td>None</td>
    </tr>
    <tr>
      <th>397</th>
      <td>808106460588765185</td>
      <td>doggo</td>
      <td>None</td>
      <td>pupper</td>
      <td>None</td>
    </tr>
    <tr>
      <th>419</th>
      <td>802265048156610565</td>
      <td>doggo</td>
      <td>None</td>
      <td>pupper</td>
      <td>None</td>
    </tr>
    <tr>
      <th>425</th>
      <td>801115127852503040</td>
      <td>None</td>
      <td>None</td>
      <td>pupper</td>
      <td>None</td>
    </tr>
    <tr>
      <th>510</th>
      <td>785639753186217984</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>652</th>
      <td>759793422261743616</td>
      <td>doggo</td>
      <td>None</td>
      <td>pupper</td>
      <td>None</td>
    </tr>
    <tr>
      <th>704</th>
      <td>751583847268179968</td>
      <td>doggo</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
    </tr>
    <tr>
      <th>795</th>
      <td>741067306818797568</td>
      <td>doggo</td>
      <td>None</td>
      <td>pupper</td>
      <td>None</td>
    </tr>
    <tr>
      <th>841</th>
      <td>733109485275860992</td>
      <td>doggo</td>
      <td>None</td>
      <td>pupper</td>
      <td>None</td>
    </tr>
  </tbody>
</table>
</div>



```python
df_twitter_clean['dog_status'] = 'None'
for i in range(0,len(df_twitter_clean)):
    if df_twitter_clean.doggo[i] != 'None':
        df_twitter_clean.dog_status[i] = 'doggo'
    elif df_twitter_clean.floofer[i] != 'None':
        df_twitter_clean.dog_status[i] = 'floofer'
    elif df_twitter_clean.pupper[i] != 'None':
        df_twitter_clean.dog_status[i] = 'pupper'
    elif df_twitter_clean.puppo[i] != 'None':
        df_twitter_clean.dog_status[i] = 'puppo'
```

    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:4: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      after removing the cwd from sys.path.
    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:10: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      # Remove the CWD from sys.path while we load stuff.
    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:8: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      
    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:6: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      



```python
#df_twitter_clean
```


```python
df_twitter_clean.type = df_twitter_clean.type.replace('None','')
df_twitter_clean.dog_status = df_twitter_clean.dog_status.replace('None','')
```


```python
df_twitter_clean.type.value_counts()
```




               1652
    pupper      228
    doggo        79
    puppo        27
    floofer       8
    Name: type, dtype: int64




```python
df_twitter_clean.dog_status.value_counts()
#df_twitter_clean.dog_status
```




               1689
    pupper      205
    doggo        69
    puppo        23
    floofer       8
    Name: dog_status, dtype: int64




```python
# 整合我提取的type数据和源文件提供的dog_status数据到status
df_twitter_clean['status'] = ''
for i in range(0,len(df_twitter_clean)):
    if df_twitter_clean.type[i] != '':
        if df_twitter_clean.dog_status[i] != '':
            if df_twitter_clean.dog_status[i] == df_twitter_clean.type[i]:
                df_twitter_clean.status[i] = df_twitter_clean.type[i]
            else: df_twitter_clean.status[i] = 'needcheck'   
    else: df_twitter_clean.status[i] = df_twitter_clean.type[i] + df_twitter_clean.dog_status[i]
```

    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:9: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      if __name__ == '__main__':
    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:7: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      import sys
    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:8: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      



```python
#整理后发现dog_status还有部分数据和我自己通过text提取出的数据type不一致，dog_status的数据为正确数据。
with pd.option_context('max_colwidth', 200):
    display(df_twitter_clean[(df_twitter_clean['status']=='needcheck')][['tweet_id','status','type','dog_status','text']])
```


<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>status</th>
      <th>type</th>
      <th>dog_status</th>
      <th>text</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>148</th>
      <td>855851453814013952</td>
      <td>needcheck</td>
      <td>doggo</td>
      <td>puppo</td>
      <td>Here's a puppo participating in the #ScienceMarch. Cleverly disguising her own doggo agenda. 13/10 would keep the planet habitable for https://t.co/cMhq16isel</td>
    </tr>
    <tr>
      <th>340</th>
      <td>817777686764523521</td>
      <td>needcheck</td>
      <td>doggo</td>
      <td>pupper</td>
      <td>This is Dido. She's playing the lead role in "Pupper Stops to Catch Snow Before Resuming Shadow Box with Dried Apple." 13/10 (IG: didodoggo) https://t.co/m7isZrOBX7</td>
    </tr>
    <tr>
      <th>425</th>
      <td>801115127852503040</td>
      <td>needcheck</td>
      <td>doggo</td>
      <td>pupper</td>
      <td>This is Bones. He's being haunted by another doggo of roughly the same size. 12/10 deep breaths pupper everything's fine https://t.co/55Dqe0SJNj</td>
    </tr>
  </tbody>
</table>
</div>



```python
#观察发现dog_status是正确的，手动添加到status字段
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 855851453814013952),'status'] = 'puppo'
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 817777686764523521),'status'] = 'puppo'
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 801115127852503040),'status'] = 'puppo'
```


```python
df_twitter_clean.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 1994 entries, 0 to 1993
    Data columns (total 24 columns):
    tweet_id              1994 non-null object
    timestamp             1994 non-null object
    text                  1994 non-null object
    rating_numerator      1994 non-null int64
    rating_denominator    1994 non-null int64
    name                  1994 non-null object
    doggo                 1994 non-null object
    floofer               1994 non-null object
    pupper                1994 non-null object
    puppo                 1994 non-null object
    retweet_count         1994 non-null object
    favorite_count        1994 non-null object
    p1                    1994 non-null object
    p1_conf               1994 non-null float64
    p1_dog                1994 non-null bool
    p2                    1994 non-null object
    p2_conf               1994 non-null float64
    p2_dog                1994 non-null bool
    p3                    1994 non-null object
    p3_conf               1994 non-null float64
    p3_dog                1994 non-null bool
    type                  1994 non-null object
    dog_status            1994 non-null object
    status                1994 non-null object
    dtypes: bool(3), float64(3), int64(2), object(16)
    memory usage: 428.6+ KB



```python
#删除多余列
df_twitter_clean = df_twitter_clean.drop(['doggo','floofer','pupper','puppo','dog_status','type'],axis=1)
```

### 测试


```python
df_twitter_clean.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 1994 entries, 0 to 1993
    Data columns (total 18 columns):
    tweet_id              1994 non-null object
    timestamp             1994 non-null object
    text                  1994 non-null object
    rating_numerator      1994 non-null int64
    rating_denominator    1994 non-null int64
    name                  1994 non-null object
    retweet_count         1994 non-null object
    favorite_count        1994 non-null object
    p1                    1994 non-null object
    p1_conf               1994 non-null float64
    p1_dog                1994 non-null bool
    p2                    1994 non-null object
    p2_conf               1994 non-null float64
    p2_dog                1994 non-null bool
    p3                    1994 non-null object
    p3_conf               1994 non-null float64
    p3_dog                1994 non-null bool
    status                1994 non-null object
    dtypes: bool(3), float64(3), int64(2), object(10)
    memory usage: 335.1+ KB


## 数据质量清洗
### 定义
* Q2_`tweet_id`的类型为int64，`in_reply_to_status_id` & `in_reply_to_user_id` 的类型为64位浮点，实际上这列不需要进行计算，我们需要将所有的ID列都转化为字符串格式
* Q3_`timestamp`时间戳的数据格式为object，应当转换为timedate
* Q7_`tweet_id` 和 `img_num`的类型为int64，实际上这列不需要进行计算，我们需要将这两列都转化为字符串格式
* Q8_`retweet_count`&`favorite_count`的类型应为数字类型

### 代码


```python
df_twitter_clean.timestamp=pd.to_datetime(df_twitter_clean.timestamp)
df_twitter_clean.retweet_count = df_twitter_clean.retweet_count.astype(float)
df_twitter_clean.favorite_count = df_twitter_clean.favorite_count.astype(float)
```

### 测试


```python
df_twitter_clean.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 1994 entries, 0 to 1993
    Data columns (total 18 columns):
    tweet_id              1994 non-null object
    timestamp             1994 non-null datetime64[ns]
    text                  1994 non-null object
    rating_numerator      1994 non-null int64
    rating_denominator    1994 non-null int64
    name                  1994 non-null object
    retweet_count         1994 non-null float64
    favorite_count        1994 non-null float64
    p1                    1994 non-null object
    p1_conf               1994 non-null float64
    p1_dog                1994 non-null bool
    p2                    1994 non-null object
    p2_conf               1994 non-null float64
    p2_dog                1994 non-null bool
    p3                    1994 non-null object
    p3_conf               1994 non-null float64
    p3_dog                1994 non-null bool
    status                1994 non-null object
    dtypes: bool(3), datetime64[ns](1), float64(5), int64(2), object(7)
    memory usage: 335.1+ KB


### 定义
* Q5_部分Rating评分的分值不正确,同时应将分子分母进行计算后得出一个rating值方便后续可视化分析

### 代码


```python
with pd.option_context('max_colwidth', 200):
    display(df_twitter_clean[df_twitter_clean.rating_denominator != 10][['tweet_id','name','text','rating_numerator','rating_denominator']])
```


<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>name</th>
      <th>text</th>
      <th>rating_numerator</th>
      <th>rating_denominator</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>323</th>
      <td>820690176645140481</td>
      <td>None</td>
      <td>The floofs have been released I repeat the floofs have been released. 84/70 https://t.co/NIYC820tmd</td>
      <td>84</td>
      <td>70</td>
    </tr>
    <tr>
      <th>385</th>
      <td>810984652412424192</td>
      <td>Sam</td>
      <td>Meet Sam. She smiles 24/7 &amp;amp; secretly aspires to be a reindeer. \nKeep Sam smiling by clicking and sharing this link:\nhttps://t.co/98tB8y7y7t https://t.co/LouL5vdvxx</td>
      <td>24</td>
      <td>7</td>
    </tr>
    <tr>
      <th>662</th>
      <td>758467244762497024</td>
      <td>None</td>
      <td>Why does this never happen at my front door... 165/150 https://t.co/HmwrdfEfUE</td>
      <td>165</td>
      <td>150</td>
    </tr>
    <tr>
      <th>800</th>
      <td>740373189193256964</td>
      <td>None</td>
      <td>After so many requests, this is Bretagne. She was the last surviving 9/11 search dog, and our second ever 14/10. RIP https://t.co/XAVDNDaVgQ</td>
      <td>9</td>
      <td>11</td>
    </tr>
    <tr>
      <th>848</th>
      <td>731156023742988288</td>
      <td>this</td>
      <td>Say hello to this unbelievably well behaved squad of doggos. 204/170 would try to pet all at once https://t.co/yGQI3He3xv</td>
      <td>204</td>
      <td>170</td>
    </tr>
    <tr>
      <th>891</th>
      <td>722974582966214656</td>
      <td>None</td>
      <td>Happy 4/20 from the squad! 13/10 for all https://t.co/eV1diwds8a</td>
      <td>4</td>
      <td>20</td>
    </tr>
    <tr>
      <th>925</th>
      <td>716439118184652801</td>
      <td>Bluebert</td>
      <td>This is Bluebert. He just saw that both #FinalFur match ups are split 50/50. Amazed af. 11/10 https://t.co/Kky1DPG4iq</td>
      <td>50</td>
      <td>50</td>
    </tr>
    <tr>
      <th>946</th>
      <td>713900603437621249</td>
      <td>None</td>
      <td>Happy Saturday here's 9 puppers on a bench. 99/90 good work everybody https://t.co/mpvaVxKmc1</td>
      <td>99</td>
      <td>90</td>
    </tr>
    <tr>
      <th>970</th>
      <td>710658690886586372</td>
      <td>None</td>
      <td>Here's a brigade of puppers. All look very prepared for whatever happens next. 80/80 https://t.co/0eb7R1Om12</td>
      <td>80</td>
      <td>80</td>
    </tr>
    <tr>
      <th>988</th>
      <td>709198395643068416</td>
      <td>None</td>
      <td>From left to right:\nCletus, Jerome, Alejandro, Burp, &amp;amp; Titson\nNone know where camera is. 45/50 would hug all at once https://t.co/sedre1ivTK</td>
      <td>45</td>
      <td>50</td>
    </tr>
    <tr>
      <th>1054</th>
      <td>704054845121142784</td>
      <td>a</td>
      <td>Here is a whole flock of puppers.  60/50 I'll take the lot https://t.co/9dpcw6MdWa</td>
      <td>60</td>
      <td>50</td>
    </tr>
    <tr>
      <th>1130</th>
      <td>697463031882764288</td>
      <td>None</td>
      <td>Happy Wednesday here's a bucket of pups. 44/40 would pet all at once https://t.co/HppvrYuamZ</td>
      <td>44</td>
      <td>40</td>
    </tr>
    <tr>
      <th>1302</th>
      <td>684225744407494656</td>
      <td>None</td>
      <td>Two sneaky puppers were not initially seen, moving the rating to 143/130. Please forgive us. Thank you https://t.co/kRK51Y5ac3</td>
      <td>143</td>
      <td>130</td>
    </tr>
    <tr>
      <th>1303</th>
      <td>684222868335505415</td>
      <td>None</td>
      <td>Someone help the girl is being mugged. Several are distracting her while two steal her shoes. Clever puppers 121/110 https://t.co/1zfnTJLt55</td>
      <td>121</td>
      <td>110</td>
    </tr>
    <tr>
      <th>1328</th>
      <td>682962037429899265</td>
      <td>Darrel</td>
      <td>This is Darrel. He just robbed a 7/11 and is in a high speed police chase. Was just spotted by the helicopter 10/10 https://t.co/7EsP8LmSp5</td>
      <td>7</td>
      <td>11</td>
    </tr>
    <tr>
      <th>1435</th>
      <td>677716515794329600</td>
      <td>None</td>
      <td>IT'S PUPPERGEDDON. Total of 144/120 ...I think https://t.co/ZanVtAtvIq</td>
      <td>144</td>
      <td>120</td>
    </tr>
    <tr>
      <th>1494</th>
      <td>675853064436391936</td>
      <td>None</td>
      <td>Here we have an entire platoon of puppers. Total score: 88/80 would pet all at once https://t.co/y93p6FLvVw</td>
      <td>88</td>
      <td>80</td>
    </tr>
    <tr>
      <th>1973</th>
      <td>666287406224695296</td>
      <td>an</td>
      <td>This is an Albanian 3 1/2 legged  Episcopalian. Loves well-polished hardwood flooring. Penis on the collar. 9/10 https://t.co/d9NcXFKwLv</td>
      <td>1</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>



```python
#对于取值错误的进行修改，对于比例用错的不用修改
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 835246439529840640),('rating_numerator','rating_denominator')] = 13,10
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 832088576586297345),('rating_numerator','rating_denominator')] = np.nan
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 810984652412424192),('rating_numerator','rating_denominator')] = np.nan
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 775096608509886464),('rating_numerator','rating_denominator')] = 14,10
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 740373189193256964),('rating_numerator','rating_denominator')] = 14,10
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 722974582966214656),('rating_numerator','rating_denominator')] = 13,10
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 716439118184652801),('rating_numerator','rating_denominator')] = 11,10
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 682962037429899265),('rating_numerator','rating_denominator')] = 10,10
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 666287406224695296),('rating_numerator','rating_denominator')] = 9,10

#其他还需调整的数据包括
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 832215909146226688),('rating_numerator','rating_denominator')] = 9.75,10
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 786709082849828864),('rating_numerator','rating_denominator')] = 9.75,10
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 778027034220126208),('rating_numerator','rating_denominator')] = 11.27,10
df_twitter_clean.loc[(df_twitter_clean.tweet_id == 680494726643068929),('rating_numerator','rating_denominator')] = 11.26,10

```


```python
df_twitter_clean['rating'] = df_twitter_clean['rating_numerator'] / df_twitter_clean['rating_denominator']
df_twitter_clean.rating.value_counts()
```




    1.200      454
    1.000      421
    1.100      403
    1.300      262
    0.900      152
    0.800       95
    0.700       51
    1.400       36
    0.500       33
    0.600       32
    0.300       19
    0.400       15
    0.200        9
    0.100        4
    0.000        2
    1.127        1
    1.126        1
    0.975        1
    42.000       1
    177.600      1
    Name: rating, dtype: int64




```python
with pd.option_context('max_colwidth', 200):
    display(df_twitter_clean[(df_twitter_clean.rating>2) | (df_twitter_clean.rating<0.2)][['tweet_id','rating','text','rating_numerator','rating_denominator']])
```


<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>rating</th>
      <th>text</th>
      <th>rating_numerator</th>
      <th>rating_denominator</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>235</th>
      <td>835152434251116546</td>
      <td>0.0</td>
      <td>When you're so blinded by your systematic plagiarism that you forget what day it is. 0/10 https://t.co/YbEJPkg4Ag</td>
      <td>0.0</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>726</th>
      <td>749981277374128128</td>
      <td>177.6</td>
      <td>This is Atticus. He's quite simply America af. 1776/10 https://t.co/GRXwMxLBkh</td>
      <td>1776.0</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>756</th>
      <td>746906459439529985</td>
      <td>0.0</td>
      <td>PUPDATE: can't see any. Even if I could, I couldn't reach them to pet. 0/10 much disappointment https://t.co/c7WXaB2nqX</td>
      <td>0.0</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>1519</th>
      <td>675153376133427200</td>
      <td>0.1</td>
      <td>What kind of person sends in a picture without a dog in it? 1/10 just because that's a nice table https://t.co/RDXCfk8hK0</td>
      <td>1.0</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>1718</th>
      <td>670842764863651840</td>
      <td>42.0</td>
      <td>After so many requests... here you go.\n\nGood dogg. 420/10 https://t.co/yfAAo1gdeY</td>
      <td>420.0</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>1735</th>
      <td>670783437142401025</td>
      <td>0.1</td>
      <td>Flamboyant pup here. Probably poisonous. Won't eat kibble. Doesn't bark. Slow af. Petting doesn't look fun. 1/10 https://t.co/jxukeh2BeO</td>
      <td>1.0</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>1900</th>
      <td>667549055577362432</td>
      <td>0.1</td>
      <td>Never seen dog like this. Breathes heavy. Tilts head in a pattern. No bark. Shitty at fetch. Not even cordless. 1/10 https://t.co/i9iSGNn3fx</td>
      <td>1.0</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>1976</th>
      <td>666104133288665088</td>
      <td>0.1</td>
      <td>Not familiar with this breed. No tail (weird). Only 2 legs. Doesn't bark. Surprisingly quick. Shits eggs. 1/10 https://t.co/Asgdc6kuLX</td>
      <td>1.0</td>
      <td>10.0</td>
    </tr>
  </tbody>
</table>
</div>



```python
df_twitter_clean = df_twitter_clean.drop(['rating_numerator','rating_denominator'],axis = 1)
```

### 测试


```python
df_twitter_clean.rating.value_counts()
```




    1.200      454
    1.000      421
    1.100      403
    1.300      262
    0.900      152
    0.800       95
    0.700       51
    1.400       36
    0.500       33
    0.600       32
    0.300       19
    0.400       15
    0.200        9
    0.100        4
    0.000        2
    1.127        1
    1.126        1
    0.975        1
    42.000       1
    177.600      1
    Name: rating, dtype: int64




```python
df_twitter_clean.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 1994 entries, 0 to 1993
    Data columns (total 17 columns):
    tweet_id          1994 non-null object
    timestamp         1994 non-null datetime64[ns]
    text              1994 non-null object
    name              1994 non-null object
    retweet_count     1994 non-null float64
    favorite_count    1994 non-null float64
    p1                1994 non-null object
    p1_conf           1994 non-null float64
    p1_dog            1994 non-null bool
    p2                1994 non-null object
    p2_conf           1994 non-null float64
    p2_dog            1994 non-null bool
    p3                1994 non-null object
    p3_conf           1994 non-null float64
    p3_dog            1994 non-null bool
    status            1994 non-null object
    rating            1993 non-null float64
    dtypes: bool(3), datetime64[ns](1), float64(6), object(7)
    memory usage: 319.5+ KB


### 定义
* Q1_部分`name`列信息缺失，需要补全狗的名字，同时部分狗的名字提取不正确

### 代码


```python
#狗的姓名与我们要分析的目标不相关，故近调查部分明显提取错误的狗名，进行更改
df_twitter_clean.name.value_counts()
```




    None        546
    a            55
    Charlie      11
    Oliver       10
    Lucy         10
    Cooper       10
    Penny         9
    Tucker        9
    Winston       8
    Sadie         8
    Lola          7
    Daisy         7
    Toby          7
    the           7
    Jax           6
    Bo            6
    Koda          6
    Stanley       6
    Bella         6
    an            6
    Rusty         5
    Bailey        5
    Louis         5
    Scout         5
    Chester       5
    Dave          5
    Milo          5
    Leo           5
    Oscar         5
    Buddy         5
               ... 
    Jarod         1
    Spencer       1
    Kollin        1
    Sailor        1
    Shikha        1
    Zooey         1
    Bauer         1
    Arya          1
    Wafer         1
    Rorie         1
    Cheryl        1
    Coleman       1
    Crimson       1
    Berb          1
    Mitch         1
    Pippin        1
    Vince         1
    Emanuel       1
    Aja           1
    Jockson       1
    Florence      1
    Rumpole       1
    Kallie        1
    Sully         1
    Bobbay        1
    Mingus        1
    Lucky         1
    Nigel         1
    Swagger       1
    Bradlay       1
    Name: name, Length: 936, dtype: int64




```python
with pd.option_context('max_colwidth', 200):
    display(df_twitter_clean[(df_twitter_clean.name == 'a') | (df_twitter_clean.name == 'the') | (df_twitter_clean.name == 'an')| (df_twitter_clean.name == 'old')][['tweet_id','text','name']])
```


<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>text</th>
      <th>name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>49</th>
      <td>881536004380872706</td>
      <td>Here is a pupper approaching maximum borkdrive. Zooming at never before seen speeds. 14/10 paw-inspiring af \n(IG: puffie_the_chow) https://t.co/ghXBIIeQZF</td>
      <td>a</td>
    </tr>
    <tr>
      <th>472</th>
      <td>792913359805018113</td>
      <td>Here is a perfect example of someone who has their priorities in order. 13/10 for both owner and Forrest https://t.co/LRyMrU7Wfq</td>
      <td>a</td>
    </tr>
    <tr>
      <th>582</th>
      <td>772581559778025472</td>
      <td>Guys this is getting so out of hand. We only rate dogs. This is a Galapagos Speed Panda. Pls only send dogs... 10/10 https://t.co/8lpAGaZRFn</td>
      <td>a</td>
    </tr>
    <tr>
      <th>746</th>
      <td>747885874273214464</td>
      <td>This is a mighty rare blue-tailed hammer sherk. Human almost lost a limb trying to take these. Be careful guys. 8/10 https://t.co/TGenMeXreW</td>
      <td>a</td>
    </tr>
    <tr>
      <th>748</th>
      <td>747816857231626240</td>
      <td>Viewer discretion is advised. This is a terrible attack in progress. Not even in water (tragic af). 4/10 bad sherk https://t.co/L3U0j14N5R</td>
      <td>a</td>
    </tr>
    <tr>
      <th>757</th>
      <td>746872823977771008</td>
      <td>This is a carrot. We only rate dogs. Please only send in dogs. You all really should know this by now ...11/10 https://t.co/9e48aPrBm2</td>
      <td>a</td>
    </tr>
    <tr>
      <th>762</th>
      <td>746369468511756288</td>
      <td>This is an Iraqi Speed Kangaroo. It is not a dog. Please only send in dogs. I'm very angry with all of you ...9/10 https://t.co/5qpBTTpgUt</td>
      <td>an</td>
    </tr>
    <tr>
      <th>783</th>
      <td>743222593470234624</td>
      <td>This is a very rare Great Alaskan Bush Pupper. Hard to stumble upon without spooking. 12/10 would pet passionately https://t.co/xOBKCdpzaa</td>
      <td>a</td>
    </tr>
    <tr>
      <th>919</th>
      <td>717537687239008257</td>
      <td>People please. This is a Deadly Mediterranean Plop T-Rex. We only rate dogs. Only send in dogs. Thanks you... 11/10 https://t.co/2ATDsgHD4n</td>
      <td>a</td>
    </tr>
    <tr>
      <th>929</th>
      <td>715733265223708672</td>
      <td>This is a taco. We only rate dogs. Please only send in dogs. Dogs are what we rate. Not tacos. Thank you... 10/10 https://t.co/cxl6xGY8B9</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1045</th>
      <td>704859558691414016</td>
      <td>Here is a heartbreaking scene of an incredible pupper being laid to rest. 10/10 RIP pupper https://t.co/81mvJ0rGRu</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1054</th>
      <td>704054845121142784</td>
      <td>Here is a whole flock of puppers.  60/50 I'll take the lot https://t.co/9dpcw6MdWa</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1064</th>
      <td>703079050210877440</td>
      <td>This is a Butternut Cumberfloof. It's not windy they just look like that. 11/10 back at it again with the red socks https://t.co/hMjzhdUHaW</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1065</th>
      <td>703041949650034688</td>
      <td>This is an East African Chalupa Seal. We only rate dogs. Please only send in dogs. Thank you... 10/10 https://t.co/iHe6liLwWR</td>
      <td>an</td>
    </tr>
    <tr>
      <th>1070</th>
      <td>702539513671897089</td>
      <td>This is a Wild Tuscan Poofwiggle. Careful not to startle. Rare tongue slip. One eye magical. 12/10 would def pet https://t.co/4EnShAQjv6</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1082</th>
      <td>700864154249383937</td>
      <td>"Pupper is a present to world. Here is a bow for pupper." 12/10 precious as hell https://t.co/ItSsE92gCW</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1185</th>
      <td>692187005137076224</td>
      <td>This is a rare Arctic Wubberfloof. Unamused by the happenings. No longer has the appetites. 12/10 would totally hug https://t.co/krvbacIX0N</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1209</th>
      <td>690360449368465409</td>
      <td>Stop sending in lobsters. This is the final warning. We only rate dogs. Thank you... 9/10 https://t.co/B9ZXXKJYNx</td>
      <td>the</td>
    </tr>
    <tr>
      <th>1275</th>
      <td>685943807276412928</td>
      <td>This is the newly formed pupper a capella group. They're just starting out but I see tons of potential. 8/10 for all https://t.co/wbAcvFoNtn</td>
      <td>the</td>
    </tr>
    <tr>
      <th>1398</th>
      <td>679530280114372609</td>
      <td>Guys this really needs to stop. We've been over this way too many times. This is a giraffe. We only rate dogs.. 7/10 https://t.co/yavgkHYPOC</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1441</th>
      <td>677644091929329666</td>
      <td>This is a dog swinging. I really enjoyed it so I hope you all do as well. 11/10 https://t.co/Ozo9KHTRND</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1452</th>
      <td>677269281705472000</td>
      <td>This is the happiest pupper I've ever seen. 10/10 would trade lives with https://t.co/ep8ATEJwRb</td>
      <td>the</td>
    </tr>
    <tr>
      <th>1469</th>
      <td>676613908052996102</td>
      <td>This is the saddest/sweetest/best picture I've been sent. 12/10 😢🐶 https://t.co/vQ2Lw1BLBF</td>
      <td>the</td>
    </tr>
    <tr>
      <th>1503</th>
      <td>675706639471788032</td>
      <td>This is a Sizzlin Menorah spaniel from Brooklyn named Wylie. Lovable eyes. Chiller as hell. 10/10 and I'm out.. poof https://t.co/7E0AiJXPmI</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1504</th>
      <td>675534494439489536</td>
      <td>Seriously guys?! Only send in dogs. I only rate dogs. This is a baby black bear... 11/10 https://t.co/H7kpabTfLj</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1527</th>
      <td>675109292475830276</td>
      <td>C'mon guys. We've been over this. We only rate dogs. This is a cow. Please only submit dogs. Thank you...... 9/10 https://t.co/WjcELNEqN2</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1528</th>
      <td>675047298674663426</td>
      <td>This is a fluffy albino Bacardi Columbia mix. Excellent at the tweets. 11/10 would hug gently https://t.co/diboDRUuEI</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1569</th>
      <td>674082852460433408</td>
      <td>This is a Sagitariot Baklava mix. Loves her new hat. 11/10 radiant pup https://t.co/Bko5kFJYUU</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1586</th>
      <td>673715861853720576</td>
      <td>This is a heavily opinionated dog. Loves walls. Nobody knows how the hair works. Always ready for a kiss. 4/10 https://t.co/dFiaKZ9cDl</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1600</th>
      <td>673636718965334016</td>
      <td>This is a Lofted Aphrodisiac Terrier named Kip. Big fan of bed n breakfasts. Fits perfectly. 10/10 would pet firmly https://t.co/gKlLpNzIl3</td>
      <td>a</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1796</th>
      <td>669661792646373376</td>
      <td>This is a brave dog. Excellent free climber. Trying to get closer to God. Not very loyal though. Doesn't bark. 5/10 https://t.co/ODnILTr4QM</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1804</th>
      <td>669564461267722241</td>
      <td>This is a Coriander Baton Rouge named Alfredo. Loves to cuddle with smaller well-dressed dog. 10/10 would hug lots https://t.co/eCRdwouKCl</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1833</th>
      <td>668955713004314625</td>
      <td>This is a Slovakian Helter Skelter Feta named Leroi. Likes to skip on roofs. Good traction. Much balance. 10/10 wow! https://t.co/Dmy2mY2Qj5</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1840</th>
      <td>668815180734689280</td>
      <td>This is a wild Toblerone from Papua New Guinea. Mouth always open. Addicted to hay. Acts blind. 7/10 handsome dog https://t.co/IGmVbz07tZ</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1846</th>
      <td>668636665813057536</td>
      <td>This is an Irish Rigatoni terrier named Berta. Completely made of rope. No eyes. Quite large. Loves to dance. 10/10 https://t.co/EM5fDykrJg</td>
      <td>an</td>
    </tr>
    <tr>
      <th>1853</th>
      <td>668614819948453888</td>
      <td>Here is a horned dog. Much grace. Can jump over moons (dam!). Paws not soft. Bad at barking. 7/10 can still pet tho https://t.co/2Su7gmsnZm</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1859</th>
      <td>668507509523615744</td>
      <td>This is a Birmingham Quagmire named Chuk. Loves to relax and watch the game while sippin on that iced mocha. 10/10 https://t.co/HvNg9JWxFt</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1863</th>
      <td>668466899341221888</td>
      <td>Here is a mother dog caring for her pups. Snazzy red mohawk. Doesn't wag tail. Pups look confused. Overall 4/10 https://t.co/YOHe6lf09m</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1876</th>
      <td>668171859951755264</td>
      <td>This is a Trans Siberian Kellogg named Alfonso. Huge ass eyeballs. Actually Dobby from Harry Potter. 7/10 https://t.co/XpseHBlAAb</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1890</th>
      <td>667861340749471744</td>
      <td>This is a Shotokon Macadamia mix named Cheryl. Sophisticated af. Looks like a disappointed librarian. Shh (lol) 9/10 https://t.co/J4GnJ5Swba</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1896</th>
      <td>667773195014021121</td>
      <td>This is a rare Hungarian Pinot named Jessiga. She is either mid-stroke or got stuck in the washing machine. 8/10 https://t.co/ZU0i0KJyqD</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1903</th>
      <td>667538891197542400</td>
      <td>This is a southwest Coriander named Klint. Hat looks expensive. Still on house arrest :(\n9/10 https://t.co/IQTOMqDUIe</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1912</th>
      <td>667470559035432960</td>
      <td>This is a northern Wahoo named Kohl. He runs this town. Chases tumbleweeds. Draws gun wicked fast. 11/10 legendary https://t.co/J4vn2rOYFk</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1926</th>
      <td>667177989038297088</td>
      <td>This is a Dasani Kingfisher from Maine. His name is Daryl. Daryl doesn't like being swallowed by a panda. 8/10 https://t.co/jpaeu6LNmW</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1942</th>
      <td>666983947667116034</td>
      <td>This is a curly Ticonderoga named Pepe. No feet. Loves to jet ski. 11/10 would hug until forever https://t.co/cyDfaK8NBc</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1949</th>
      <td>666781792255496192</td>
      <td>This is a purebred Bacardi named Octaviath. Can shoot spaghetti out of mouth. 10/10 https://t.co/uEvsGLOFHa</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1952</th>
      <td>666701168228331520</td>
      <td>This is a golden Buckminsterfullerene named Johm. Drives trucks. Lumberjack (?). Enjoys wall. 8/10 would hug softly https://t.co/uQbZJM2DQB</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1965</th>
      <td>666407126856765440</td>
      <td>This is a southern Vesuvius bumblegruff. Can drive a truck (wow). Made friends with 5 other nifty dogs (neat). 7/10 https://t.co/LopTBkKa8h</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1971</th>
      <td>666337882303524864</td>
      <td>This is an extremely rare horned Parthenon. Not amused. Wears shoes. Overall very nice. 9/10 would pet aggressively https://t.co/QpRjllzWAL</td>
      <td>an</td>
    </tr>
    <tr>
      <th>1972</th>
      <td>666293911632134144</td>
      <td>This is a funny dog. Weird toes. Won't come down. Loves branch. Refuses to eat his food. Hard to cuddle with. 3/10 https://t.co/IIXis0zta0</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1973</th>
      <td>666287406224695296</td>
      <td>This is an Albanian 3 1/2 legged  Episcopalian. Loves well-polished hardwood flooring. Penis on the collar. 9/10 https://t.co/d9NcXFKwLv</td>
      <td>an</td>
    </tr>
    <tr>
      <th>1983</th>
      <td>666063827256086533</td>
      <td>This is the happiest dog you will ever see. Very committed owner. Nice couch. 10/10 https://t.co/RhUEAloehK</td>
      <td>the</td>
    </tr>
    <tr>
      <th>1984</th>
      <td>666058600524156928</td>
      <td>Here is the Rand Paul of retrievers folks! He's probably good at poker. Can drink beer (lol rad). 8/10 good dog https://t.co/pYAJkAe76p</td>
      <td>the</td>
    </tr>
    <tr>
      <th>1985</th>
      <td>666057090499244032</td>
      <td>My oh my. This is a rare blond Canadian terrier on wheels. Only $8.98. Rather docile. 9/10 very rare https://t.co/yWBqbrzy8O</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1986</th>
      <td>666055525042405380</td>
      <td>Here is a Siberian heavily armored polar bear mix. Strong owner. 10/10 I would do unspeakable things to pet this dog https://t.co/rdivxLiqEt</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1987</th>
      <td>666051853826850816</td>
      <td>This is an odd dog. Hard on the outside but loving on the inside. Petting still fun. Doesn't play catch well. 2/10 https://t.co/v5A4vzSDdc</td>
      <td>an</td>
    </tr>
    <tr>
      <th>1988</th>
      <td>666050758794694657</td>
      <td>This is a truly beautiful English Wilson Staff retriever. Has a nice phone. Privileged. 10/10 would trade lives with https://t.co/fvIbQfHjIe</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1990</th>
      <td>666044226329800704</td>
      <td>This is a purebred Piers Morgan. Loves to Netflix and chill. Always looks like he forgot to unplug the iron. 6/10 https://t.co/DWnyCjf2mx</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1991</th>
      <td>666033412701032449</td>
      <td>Here is a very happy pup. Big fan of well-maintained decks. Just look at that tongue. 9/10 would cuddle af https://t.co/y671yMhoiR</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1992</th>
      <td>666029285002620928</td>
      <td>This is a western brown Mitsubishi terrier. Upset about leaf. Actually 2 dogs here. 7/10 would walk the shit out of https://t.co/r7mOb2m0UI</td>
      <td>a</td>
    </tr>
  </tbody>
</table>
<p>68 rows × 3 columns</p>
</div>



```python
#很多正确的名字都是被标注在named之后，采用named方式提取一次名字 很好用的正则表达式参考网站https://regex101.com/ 
for i in range(0,len(df_twitter_clean)):
    if "named" in df_twitter_clean.text[i]:
        df_twitter_clean.name[i] = ''.join(re.findall(r"named\s(\w*)", df_twitter_clean.text[i]))
        print(i)
```

    1503


    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:4: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      after removing the cwd from sys.path.


    1600
    1679
    1710
    1760
    1769
    1772
    1790
    1804
    1809
    1833
    1846
    1859
    1868
    1876
    1890
    1896
    1903
    1908
    1912
    1942
    1949
    1952



```python
df_twitter_clean.name.value_counts()
```




    None        543
    a            36
    Charlie      11
    Lucy         10
    Oliver       10
    Cooper       10
    Penny         9
    Tucker        9
    Winston       8
    Sadie         8
    Lola          7
    the           7
    Daisy         7
    Toby          7
    Stanley       6
    Bo            6
    Jax           6
    Bella         6
    Koda          6
    Oscar         5
    Milo          5
    an            5
    Leo           5
    Rusty         5
    Buddy         5
    Dave          5
    Scout         5
    Bailey        5
    Louis         5
    Chester       5
               ... 
    Shikha        1
    Sailor        1
    Bauer         1
    Zooey         1
    Philippe      1
    Laela         1
    Ginger        1
    Wafer         1
    Brat          1
    Rorie         1
    Coleman       1
    Crimson       1
    Berb          1
    Mitch         1
    Pippin        1
    Vince         1
    Emanuel       1
    Aja           1
    Jockson       1
    Rumpole       1
    Karma         1
    Kallie        1
    Sully         1
    Bobbay        1
    Mingus        1
    Lucky         1
    Nigel         1
    Swagger       1
    Florence      1
    Bradlay       1
    Name: name, Length: 955, dtype: int64



reviwer建议： This is|Meet|name is|Say hello to|named 这几种不同类型的信号词，后面基本都是跟的是狗的名字。
但我发现更正掉named的信号词的词条后，还有错误提取了冠词的现象，而这些现象往往都是以This is|Meet|等为提取信号词而错误提取的。
由于name本身不是我研究的主要对象，故还是保留了之提取named信号词的动作。其余的还是按照元数据提供的name信息进行分析


```python
with pd.option_context('max_colwidth', 200):
    display(df_twitter_clean[(df_twitter_clean.name == 'a') | (df_twitter_clean.name == 'the') | (df_twitter_clean.name == 'an')| (df_twitter_clean.name == 'old')][['tweet_id','text','name']])
```


<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>text</th>
      <th>name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>49</th>
      <td>881536004380872706</td>
      <td>Here is a pupper approaching maximum borkdrive. Zooming at never before seen speeds. 14/10 paw-inspiring af \n(IG: puffie_the_chow) https://t.co/ghXBIIeQZF</td>
      <td>a</td>
    </tr>
    <tr>
      <th>472</th>
      <td>792913359805018113</td>
      <td>Here is a perfect example of someone who has their priorities in order. 13/10 for both owner and Forrest https://t.co/LRyMrU7Wfq</td>
      <td>a</td>
    </tr>
    <tr>
      <th>582</th>
      <td>772581559778025472</td>
      <td>Guys this is getting so out of hand. We only rate dogs. This is a Galapagos Speed Panda. Pls only send dogs... 10/10 https://t.co/8lpAGaZRFn</td>
      <td>a</td>
    </tr>
    <tr>
      <th>746</th>
      <td>747885874273214464</td>
      <td>This is a mighty rare blue-tailed hammer sherk. Human almost lost a limb trying to take these. Be careful guys. 8/10 https://t.co/TGenMeXreW</td>
      <td>a</td>
    </tr>
    <tr>
      <th>748</th>
      <td>747816857231626240</td>
      <td>Viewer discretion is advised. This is a terrible attack in progress. Not even in water (tragic af). 4/10 bad sherk https://t.co/L3U0j14N5R</td>
      <td>a</td>
    </tr>
    <tr>
      <th>757</th>
      <td>746872823977771008</td>
      <td>This is a carrot. We only rate dogs. Please only send in dogs. You all really should know this by now ...11/10 https://t.co/9e48aPrBm2</td>
      <td>a</td>
    </tr>
    <tr>
      <th>762</th>
      <td>746369468511756288</td>
      <td>This is an Iraqi Speed Kangaroo. It is not a dog. Please only send in dogs. I'm very angry with all of you ...9/10 https://t.co/5qpBTTpgUt</td>
      <td>an</td>
    </tr>
    <tr>
      <th>783</th>
      <td>743222593470234624</td>
      <td>This is a very rare Great Alaskan Bush Pupper. Hard to stumble upon without spooking. 12/10 would pet passionately https://t.co/xOBKCdpzaa</td>
      <td>a</td>
    </tr>
    <tr>
      <th>919</th>
      <td>717537687239008257</td>
      <td>People please. This is a Deadly Mediterranean Plop T-Rex. We only rate dogs. Only send in dogs. Thanks you... 11/10 https://t.co/2ATDsgHD4n</td>
      <td>a</td>
    </tr>
    <tr>
      <th>929</th>
      <td>715733265223708672</td>
      <td>This is a taco. We only rate dogs. Please only send in dogs. Dogs are what we rate. Not tacos. Thank you... 10/10 https://t.co/cxl6xGY8B9</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1045</th>
      <td>704859558691414016</td>
      <td>Here is a heartbreaking scene of an incredible pupper being laid to rest. 10/10 RIP pupper https://t.co/81mvJ0rGRu</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1054</th>
      <td>704054845121142784</td>
      <td>Here is a whole flock of puppers.  60/50 I'll take the lot https://t.co/9dpcw6MdWa</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1064</th>
      <td>703079050210877440</td>
      <td>This is a Butternut Cumberfloof. It's not windy they just look like that. 11/10 back at it again with the red socks https://t.co/hMjzhdUHaW</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1065</th>
      <td>703041949650034688</td>
      <td>This is an East African Chalupa Seal. We only rate dogs. Please only send in dogs. Thank you... 10/10 https://t.co/iHe6liLwWR</td>
      <td>an</td>
    </tr>
    <tr>
      <th>1070</th>
      <td>702539513671897089</td>
      <td>This is a Wild Tuscan Poofwiggle. Careful not to startle. Rare tongue slip. One eye magical. 12/10 would def pet https://t.co/4EnShAQjv6</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1082</th>
      <td>700864154249383937</td>
      <td>"Pupper is a present to world. Here is a bow for pupper." 12/10 precious as hell https://t.co/ItSsE92gCW</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1185</th>
      <td>692187005137076224</td>
      <td>This is a rare Arctic Wubberfloof. Unamused by the happenings. No longer has the appetites. 12/10 would totally hug https://t.co/krvbacIX0N</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1209</th>
      <td>690360449368465409</td>
      <td>Stop sending in lobsters. This is the final warning. We only rate dogs. Thank you... 9/10 https://t.co/B9ZXXKJYNx</td>
      <td>the</td>
    </tr>
    <tr>
      <th>1275</th>
      <td>685943807276412928</td>
      <td>This is the newly formed pupper a capella group. They're just starting out but I see tons of potential. 8/10 for all https://t.co/wbAcvFoNtn</td>
      <td>the</td>
    </tr>
    <tr>
      <th>1398</th>
      <td>679530280114372609</td>
      <td>Guys this really needs to stop. We've been over this way too many times. This is a giraffe. We only rate dogs.. 7/10 https://t.co/yavgkHYPOC</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1441</th>
      <td>677644091929329666</td>
      <td>This is a dog swinging. I really enjoyed it so I hope you all do as well. 11/10 https://t.co/Ozo9KHTRND</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1452</th>
      <td>677269281705472000</td>
      <td>This is the happiest pupper I've ever seen. 10/10 would trade lives with https://t.co/ep8ATEJwRb</td>
      <td>the</td>
    </tr>
    <tr>
      <th>1469</th>
      <td>676613908052996102</td>
      <td>This is the saddest/sweetest/best picture I've been sent. 12/10 😢🐶 https://t.co/vQ2Lw1BLBF</td>
      <td>the</td>
    </tr>
    <tr>
      <th>1504</th>
      <td>675534494439489536</td>
      <td>Seriously guys?! Only send in dogs. I only rate dogs. This is a baby black bear... 11/10 https://t.co/H7kpabTfLj</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1527</th>
      <td>675109292475830276</td>
      <td>C'mon guys. We've been over this. We only rate dogs. This is a cow. Please only submit dogs. Thank you...... 9/10 https://t.co/WjcELNEqN2</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1528</th>
      <td>675047298674663426</td>
      <td>This is a fluffy albino Bacardi Columbia mix. Excellent at the tweets. 11/10 would hug gently https://t.co/diboDRUuEI</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1569</th>
      <td>674082852460433408</td>
      <td>This is a Sagitariot Baklava mix. Loves her new hat. 11/10 radiant pup https://t.co/Bko5kFJYUU</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1586</th>
      <td>673715861853720576</td>
      <td>This is a heavily opinionated dog. Loves walls. Nobody knows how the hair works. Always ready for a kiss. 4/10 https://t.co/dFiaKZ9cDl</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1639</th>
      <td>672604026190569472</td>
      <td>This is a baby Rand Paul. Curls for days. 11/10 would cuddle the hell out of https://t.co/xHXNaPAYRe</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1682</th>
      <td>671561002136281088</td>
      <td>This is the best thing I've ever seen so spread it like wildfire &amp;amp; maybe we'll find the genius who created it. 13/10 https://t.co/q6RsuOVYwU</td>
      <td>the</td>
    </tr>
    <tr>
      <th>1796</th>
      <td>669661792646373376</td>
      <td>This is a brave dog. Excellent free climber. Trying to get closer to God. Not very loyal though. Doesn't bark. 5/10 https://t.co/ODnILTr4QM</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1840</th>
      <td>668815180734689280</td>
      <td>This is a wild Toblerone from Papua New Guinea. Mouth always open. Addicted to hay. Acts blind. 7/10 handsome dog https://t.co/IGmVbz07tZ</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1853</th>
      <td>668614819948453888</td>
      <td>Here is a horned dog. Much grace. Can jump over moons (dam!). Paws not soft. Bad at barking. 7/10 can still pet tho https://t.co/2Su7gmsnZm</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1863</th>
      <td>668466899341221888</td>
      <td>Here is a mother dog caring for her pups. Snazzy red mohawk. Doesn't wag tail. Pups look confused. Overall 4/10 https://t.co/YOHe6lf09m</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1926</th>
      <td>667177989038297088</td>
      <td>This is a Dasani Kingfisher from Maine. His name is Daryl. Daryl doesn't like being swallowed by a panda. 8/10 https://t.co/jpaeu6LNmW</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1965</th>
      <td>666407126856765440</td>
      <td>This is a southern Vesuvius bumblegruff. Can drive a truck (wow). Made friends with 5 other nifty dogs (neat). 7/10 https://t.co/LopTBkKa8h</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1971</th>
      <td>666337882303524864</td>
      <td>This is an extremely rare horned Parthenon. Not amused. Wears shoes. Overall very nice. 9/10 would pet aggressively https://t.co/QpRjllzWAL</td>
      <td>an</td>
    </tr>
    <tr>
      <th>1972</th>
      <td>666293911632134144</td>
      <td>This is a funny dog. Weird toes. Won't come down. Loves branch. Refuses to eat his food. Hard to cuddle with. 3/10 https://t.co/IIXis0zta0</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1973</th>
      <td>666287406224695296</td>
      <td>This is an Albanian 3 1/2 legged  Episcopalian. Loves well-polished hardwood flooring. Penis on the collar. 9/10 https://t.co/d9NcXFKwLv</td>
      <td>an</td>
    </tr>
    <tr>
      <th>1983</th>
      <td>666063827256086533</td>
      <td>This is the happiest dog you will ever see. Very committed owner. Nice couch. 10/10 https://t.co/RhUEAloehK</td>
      <td>the</td>
    </tr>
    <tr>
      <th>1984</th>
      <td>666058600524156928</td>
      <td>Here is the Rand Paul of retrievers folks! He's probably good at poker. Can drink beer (lol rad). 8/10 good dog https://t.co/pYAJkAe76p</td>
      <td>the</td>
    </tr>
    <tr>
      <th>1985</th>
      <td>666057090499244032</td>
      <td>My oh my. This is a rare blond Canadian terrier on wheels. Only $8.98. Rather docile. 9/10 very rare https://t.co/yWBqbrzy8O</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1986</th>
      <td>666055525042405380</td>
      <td>Here is a Siberian heavily armored polar bear mix. Strong owner. 10/10 I would do unspeakable things to pet this dog https://t.co/rdivxLiqEt</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1987</th>
      <td>666051853826850816</td>
      <td>This is an odd dog. Hard on the outside but loving on the inside. Petting still fun. Doesn't play catch well. 2/10 https://t.co/v5A4vzSDdc</td>
      <td>an</td>
    </tr>
    <tr>
      <th>1988</th>
      <td>666050758794694657</td>
      <td>This is a truly beautiful English Wilson Staff retriever. Has a nice phone. Privileged. 10/10 would trade lives with https://t.co/fvIbQfHjIe</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1990</th>
      <td>666044226329800704</td>
      <td>This is a purebred Piers Morgan. Loves to Netflix and chill. Always looks like he forgot to unplug the iron. 6/10 https://t.co/DWnyCjf2mx</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1991</th>
      <td>666033412701032449</td>
      <td>Here is a very happy pup. Big fan of well-maintained decks. Just look at that tongue. 9/10 would cuddle af https://t.co/y671yMhoiR</td>
      <td>a</td>
    </tr>
    <tr>
      <th>1992</th>
      <td>666029285002620928</td>
      <td>This is a western brown Mitsubishi terrier. Upset about leaf. Actually 2 dogs here. 7/10 would walk the shit out of https://t.co/r7mOb2m0UI</td>
      <td>a</td>
    </tr>
  </tbody>
</table>
</div>



```python
df_twitter_clean.loc[(df_twitter_clean.name == 'a'),'name'] = 'None'
df_twitter_clean.loc[(df_twitter_clean.name == 'an'),'name'] = 'None'
df_twitter_clean.loc[(df_twitter_clean.name == 'the'),'name'] = 'None'
```

### 测试


```python
df_twitter_clean.name.value_counts()
```




    None        591
    Charlie      11
    Oliver       10
    Lucy         10
    Cooper       10
    Tucker        9
    Penny         9
    Winston       8
    Sadie         8
    Daisy         7
    Toby          7
    Lola          7
    Bo            6
    Stanley       6
    Bella         6
    Jax           6
    Koda          6
    Oscar         5
    Leo           5
    Rusty         5
    Milo          5
    Buddy         5
    Dave          5
    Chester       5
    Louis         5
    Bailey        5
    Scout         5
    Finn          4
    Gus           4
    Scooter       4
               ... 
    Spencer       1
    Shikha        1
    Sailor        1
    Bauer         1
    Zooey         1
    Philippe      1
    Wafer         1
    Florence      1
    Miley         1
    Swagger       1
    Trip          1
    Berb          1
    Coleman       1
    Crimson       1
    Mitch         1
    Pippin        1
    Vince         1
    Emanuel       1
    Aja           1
    Jockson       1
    Karma         1
    Rumpole       1
    Cupid         1
    Kallie        1
    Sully         1
    Bobbay        1
    Mingus        1
    Lucky         1
    Nigel         1
    Bradlay       1
    Name: name, Length: 952, dtype: int64



### 定义
* 我们希望是有一列可以大致的预测狗的品种，整合P1~P3

### 代码


```python
df_twitter_clean['p_conf'] = 'None'
df_twitter_clean['p_dog'] = 'None'
df_twitter_clean['p'] = 'None'

#print(df_twitter_clean.p1_dog[1] == True)

for i in range(0,len(df_twitter_clean)):
    if df_twitter_clean.p1_dog[i] == True:
        df_twitter_clean['p'][i] = df_twitter_clean['p1'][i]
        df_twitter_clean['p_conf'][i] = df_twitter_clean['p1_conf'][i]
        df_twitter_clean['p_dog'][i] = df_twitter_clean['p1_dog'][i]
    elif df_twitter_clean.p2_dog[i] == True:
        df_twitter_clean['p'][i] = df_twitter_clean['p2'][i]
        df_twitter_clean['p_conf'][i] = df_twitter_clean['p2_conf'][i]
        df_twitter_clean['p_dog'][i] = df_twitter_clean['p2_dog'][i]
    elif df_twitter_clean.p3_dog[i] == True:
        df_twitter_clean['p'][i] = df_twitter_clean['p3'][i]
        df_twitter_clean['p_conf'][i] = df_twitter_clean['p3_conf'][i]
        df_twitter_clean['p_dog'][i] = df_twitter_clean['p3_dog'][i]
    else: df_twitter_clean.p_dog[i] = df_twitter_clean.p3_dog[i]

```

    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:20: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:9: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      if __name__ == '__main__':
    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:10: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      # Remove the CWD from sys.path while we load stuff.
    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:11: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      # This is added back by InteractiveShellApp.init_path()
    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:13: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      del sys.path[0]
    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:14: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      
    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:15: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      from ipykernel import kernelapp as app
    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:17: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:18: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
    /opt/conda/lib/python3.6/site-packages/ipykernel_launcher.py:19: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy



```python
with pd.option_context('max_colwidth', 200):
    display(df_twitter_clean[200:250][['tweet_id','p','p_dog','p_conf','p1','p1_dog','p1_conf','p2','p2_dog','p2_conf','p3','p3_dog','p3_conf']])
```


<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tweet_id</th>
      <th>p</th>
      <th>p_dog</th>
      <th>p_conf</th>
      <th>p1</th>
      <th>p1_dog</th>
      <th>p1_conf</th>
      <th>p2</th>
      <th>p2_dog</th>
      <th>p2_conf</th>
      <th>p3</th>
      <th>p3_dog</th>
      <th>p3_conf</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>200</th>
      <td>842846295480000512</td>
      <td>Labrador_retriever</td>
      <td>True</td>
      <td>0.461076</td>
      <td>Labrador_retriever</td>
      <td>True</td>
      <td>0.461076</td>
      <td>golden_retriever</td>
      <td>True</td>
      <td>0.154946</td>
      <td>Chihuahua</td>
      <td>True</td>
      <td>0.110249</td>
    </tr>
    <tr>
      <th>201</th>
      <td>842765311967449089</td>
      <td>Labrador_retriever</td>
      <td>True</td>
      <td>0.0293399</td>
      <td>tub</td>
      <td>False</td>
      <td>0.665238</td>
      <td>bucket</td>
      <td>False</td>
      <td>0.105166</td>
      <td>Labrador_retriever</td>
      <td>True</td>
      <td>0.029340</td>
    </tr>
    <tr>
      <th>202</th>
      <td>842535590457499648</td>
      <td>Pembroke</td>
      <td>True</td>
      <td>0.685084</td>
      <td>Pembroke</td>
      <td>True</td>
      <td>0.685084</td>
      <td>Cardigan</td>
      <td>True</td>
      <td>0.314608</td>
      <td>basenji</td>
      <td>True</td>
      <td>0.000160</td>
    </tr>
    <tr>
      <th>203</th>
      <td>842163532590374912</td>
      <td>French_bulldog</td>
      <td>True</td>
      <td>0.891227</td>
      <td>French_bulldog</td>
      <td>True</td>
      <td>0.891227</td>
      <td>soccer_ball</td>
      <td>False</td>
      <td>0.022811</td>
      <td>bull_mastiff</td>
      <td>True</td>
      <td>0.012852</td>
    </tr>
    <tr>
      <th>204</th>
      <td>842115215311396866</td>
      <td>chow</td>
      <td>True</td>
      <td>0.293493</td>
      <td>chow</td>
      <td>True</td>
      <td>0.293493</td>
      <td>Newfoundland</td>
      <td>True</td>
      <td>0.181336</td>
      <td>schipperke</td>
      <td>True</td>
      <td>0.125152</td>
    </tr>
    <tr>
      <th>205</th>
      <td>841680585030541313</td>
      <td>Chihuahua</td>
      <td>True</td>
      <td>0.547401</td>
      <td>Chihuahua</td>
      <td>True</td>
      <td>0.547401</td>
      <td>bow_tie</td>
      <td>False</td>
      <td>0.198361</td>
      <td>Pembroke</td>
      <td>True</td>
      <td>0.058493</td>
    </tr>
    <tr>
      <th>206</th>
      <td>841439858740625411</td>
      <td>Labrador_retriever</td>
      <td>True</td>
      <td>0.0481999</td>
      <td>military_uniform</td>
      <td>False</td>
      <td>0.853684</td>
      <td>Labrador_retriever</td>
      <td>True</td>
      <td>0.048200</td>
      <td>groenendael</td>
      <td>True</td>
      <td>0.015394</td>
    </tr>
    <tr>
      <th>207</th>
      <td>841314665196081154</td>
      <td>Afghan_hound</td>
      <td>True</td>
      <td>0.903712</td>
      <td>Afghan_hound</td>
      <td>True</td>
      <td>0.903712</td>
      <td>Saluki</td>
      <td>True</td>
      <td>0.035215</td>
      <td>bloodhound</td>
      <td>True</td>
      <td>0.026565</td>
    </tr>
    <tr>
      <th>208</th>
      <td>841077006473256960</td>
      <td>Brittany_spaniel</td>
      <td>True</td>
      <td>0.962985</td>
      <td>Brittany_spaniel</td>
      <td>True</td>
      <td>0.962985</td>
      <td>Blenheim_spaniel</td>
      <td>True</td>
      <td>0.014820</td>
      <td>clumber</td>
      <td>True</td>
      <td>0.009557</td>
    </tr>
    <tr>
      <th>209</th>
      <td>840696689258311684</td>
      <td>None</td>
      <td>False</td>
      <td>None</td>
      <td>web_site</td>
      <td>False</td>
      <td>0.841768</td>
      <td>rule</td>
      <td>False</td>
      <td>0.007087</td>
      <td>envelope</td>
      <td>False</td>
      <td>0.006820</td>
    </tr>
    <tr>
      <th>210</th>
      <td>840632337062862849</td>
      <td>golden_retriever</td>
      <td>True</td>
      <td>0.711148</td>
      <td>golden_retriever</td>
      <td>True</td>
      <td>0.711148</td>
      <td>cocker_spaniel</td>
      <td>True</td>
      <td>0.157929</td>
      <td>Labrador_retriever</td>
      <td>True</td>
      <td>0.059582</td>
    </tr>
    <tr>
      <th>211</th>
      <td>840370681858686976</td>
      <td>None</td>
      <td>False</td>
      <td>None</td>
      <td>teapot</td>
      <td>False</td>
      <td>0.981819</td>
      <td>cup</td>
      <td>False</td>
      <td>0.014026</td>
      <td>coffeepot</td>
      <td>False</td>
      <td>0.002421</td>
    </tr>
    <tr>
      <th>212</th>
      <td>840268004936019968</td>
      <td>Chesapeake_Bay_retriever</td>
      <td>True</td>
      <td>0.863987</td>
      <td>Chesapeake_Bay_retriever</td>
      <td>True</td>
      <td>0.863987</td>
      <td>Labrador_retriever</td>
      <td>True</td>
      <td>0.052632</td>
      <td>kelpie</td>
      <td>True</td>
      <td>0.032574</td>
    </tr>
    <tr>
      <th>213</th>
      <td>839990271299457024</td>
      <td>Staffordshire_bullterrier</td>
      <td>True</td>
      <td>0.604938</td>
      <td>Staffordshire_bullterrier</td>
      <td>True</td>
      <td>0.604938</td>
      <td>American_Staffordshire_terrier</td>
      <td>True</td>
      <td>0.311540</td>
      <td>Boston_bull</td>
      <td>True</td>
      <td>0.037159</td>
    </tr>
    <tr>
      <th>214</th>
      <td>839549326359670784</td>
      <td>Norwich_terrier</td>
      <td>True</td>
      <td>0.05248</td>
      <td>swing</td>
      <td>False</td>
      <td>0.393527</td>
      <td>Norwich_terrier</td>
      <td>True</td>
      <td>0.052480</td>
      <td>Pembroke</td>
      <td>True</td>
      <td>0.049901</td>
    </tr>
    <tr>
      <th>215</th>
      <td>839239871831150596</td>
      <td>Leonberg</td>
      <td>True</td>
      <td>0.927021</td>
      <td>Leonberg</td>
      <td>True</td>
      <td>0.927021</td>
      <td>Newfoundland</td>
      <td>True</td>
      <td>0.050009</td>
      <td>Saint_Bernard</td>
      <td>True</td>
      <td>0.010728</td>
    </tr>
    <tr>
      <th>216</th>
      <td>838921590096166913</td>
      <td>Border_terrier</td>
      <td>True</td>
      <td>0.664538</td>
      <td>Border_terrier</td>
      <td>True</td>
      <td>0.664538</td>
      <td>Brabancon_griffon</td>
      <td>True</td>
      <td>0.170451</td>
      <td>Yorkshire_terrier</td>
      <td>True</td>
      <td>0.087824</td>
    </tr>
    <tr>
      <th>217</th>
      <td>838561493054533637</td>
      <td>kelpie</td>
      <td>True</td>
      <td>0.216562</td>
      <td>kelpie</td>
      <td>True</td>
      <td>0.216562</td>
      <td>doormat</td>
      <td>False</td>
      <td>0.139994</td>
      <td>dalmatian</td>
      <td>True</td>
      <td>0.132820</td>
    </tr>
    <tr>
      <th>218</th>
      <td>838476387338051585</td>
      <td>Great_Pyrenees</td>
      <td>True</td>
      <td>0.997692</td>
      <td>Great_Pyrenees</td>
      <td>True</td>
      <td>0.997692</td>
      <td>kuvasz</td>
      <td>True</td>
      <td>0.001001</td>
      <td>Newfoundland</td>
      <td>True</td>
      <td>0.000405</td>
    </tr>
    <tr>
      <th>219</th>
      <td>838083903487373313</td>
      <td>chow</td>
      <td>True</td>
      <td>0.800975</td>
      <td>chow</td>
      <td>True</td>
      <td>0.800975</td>
      <td>seat_belt</td>
      <td>False</td>
      <td>0.164133</td>
      <td>Pomeranian</td>
      <td>True</td>
      <td>0.017981</td>
    </tr>
    <tr>
      <th>220</th>
      <td>837820167694528512</td>
      <td>golden_retriever</td>
      <td>True</td>
      <td>0.887625</td>
      <td>golden_retriever</td>
      <td>True</td>
      <td>0.887625</td>
      <td>Labrador_retriever</td>
      <td>True</td>
      <td>0.068718</td>
      <td>kuvasz</td>
      <td>True</td>
      <td>0.030387</td>
    </tr>
    <tr>
      <th>221</th>
      <td>837482249356513284</td>
      <td>None</td>
      <td>False</td>
      <td>None</td>
      <td>birdhouse</td>
      <td>False</td>
      <td>0.541196</td>
      <td>can_opener</td>
      <td>False</td>
      <td>0.121094</td>
      <td>carton</td>
      <td>False</td>
      <td>0.056137</td>
    </tr>
    <tr>
      <th>222</th>
      <td>837471256429613056</td>
      <td>Norwegian_elkhound</td>
      <td>True</td>
      <td>0.976255</td>
      <td>Norwegian_elkhound</td>
      <td>True</td>
      <td>0.976255</td>
      <td>keeshond</td>
      <td>True</td>
      <td>0.013990</td>
      <td>seat_belt</td>
      <td>False</td>
      <td>0.002111</td>
    </tr>
    <tr>
      <th>223</th>
      <td>837366284874571778</td>
      <td>American_Staffordshire_terrier</td>
      <td>True</td>
      <td>0.660085</td>
      <td>American_Staffordshire_terrier</td>
      <td>True</td>
      <td>0.660085</td>
      <td>Staffordshire_bullterrier</td>
      <td>True</td>
      <td>0.334947</td>
      <td>dalmatian</td>
      <td>True</td>
      <td>0.002697</td>
    </tr>
    <tr>
      <th>224</th>
      <td>837110210464448512</td>
      <td>Siberian_husky</td>
      <td>True</td>
      <td>0.767696</td>
      <td>Siberian_husky</td>
      <td>True</td>
      <td>0.767696</td>
      <td>Eskimo_dog</td>
      <td>True</td>
      <td>0.217079</td>
      <td>malamute</td>
      <td>True</td>
      <td>0.011657</td>
    </tr>
    <tr>
      <th>225</th>
      <td>836989968035819520</td>
      <td>toy_poodle</td>
      <td>True</td>
      <td>0.0058873</td>
      <td>shopping_cart</td>
      <td>False</td>
      <td>0.572422</td>
      <td>shopping_basket</td>
      <td>False</td>
      <td>0.414002</td>
      <td>toy_poodle</td>
      <td>True</td>
      <td>0.005887</td>
    </tr>
    <tr>
      <th>226</th>
      <td>836753516572119041</td>
      <td>schipperke</td>
      <td>True</td>
      <td>0.0115635</td>
      <td>mortarboard</td>
      <td>False</td>
      <td>0.936882</td>
      <td>academic_gown</td>
      <td>False</td>
      <td>0.020815</td>
      <td>schipperke</td>
      <td>True</td>
      <td>0.011564</td>
    </tr>
    <tr>
      <th>227</th>
      <td>836677758902222849</td>
      <td>None</td>
      <td>False</td>
      <td>None</td>
      <td>leopard</td>
      <td>False</td>
      <td>0.797410</td>
      <td>jaguar</td>
      <td>False</td>
      <td>0.095487</td>
      <td>snow_leopard</td>
      <td>False</td>
      <td>0.079694</td>
    </tr>
    <tr>
      <th>228</th>
      <td>836380477523124226</td>
      <td>None</td>
      <td>False</td>
      <td>None</td>
      <td>wooden_spoon</td>
      <td>False</td>
      <td>0.082489</td>
      <td>sliding_door</td>
      <td>False</td>
      <td>0.061017</td>
      <td>grand_piano</td>
      <td>False</td>
      <td>0.055086</td>
    </tr>
    <tr>
      <th>229</th>
      <td>836260088725786625</td>
      <td>borzoi</td>
      <td>True</td>
      <td>0.564688</td>
      <td>borzoi</td>
      <td>True</td>
      <td>0.564688</td>
      <td>ice_bear</td>
      <td>False</td>
      <td>0.078267</td>
      <td>Pembroke</td>
      <td>True</td>
      <td>0.057916</td>
    </tr>
    <tr>
      <th>230</th>
      <td>836001077879255040</td>
      <td>Samoyed</td>
      <td>True</td>
      <td>0.963558</td>
      <td>Samoyed</td>
      <td>True</td>
      <td>0.963558</td>
      <td>white_wolf</td>
      <td>False</td>
      <td>0.019848</td>
      <td>malamute</td>
      <td>True</td>
      <td>0.005904</td>
    </tr>
    <tr>
      <th>231</th>
      <td>835574547218894849</td>
      <td>Staffordshire_bullterrier</td>
      <td>True</td>
      <td>0.610655</td>
      <td>Staffordshire_bullterrier</td>
      <td>True</td>
      <td>0.610655</td>
      <td>muzzle</td>
      <td>False</td>
      <td>0.132138</td>
      <td>American_Staffordshire_terrier</td>
      <td>True</td>
      <td>0.109544</td>
    </tr>
    <tr>
      <th>232</th>
      <td>835297930240217089</td>
      <td>Rottweiler</td>
      <td>True</td>
      <td>0.341276</td>
      <td>Rottweiler</td>
      <td>True</td>
      <td>0.341276</td>
      <td>Border_terrier</td>
      <td>True</td>
      <td>0.336220</td>
      <td>Gordon_setter</td>
      <td>True</td>
      <td>0.045448</td>
    </tr>
    <tr>
      <th>233</th>
      <td>835264098648616962</td>
      <td>Chesapeake_Bay_retriever</td>
      <td>True</td>
      <td>0.0875033</td>
      <td>hyena</td>
      <td>False</td>
      <td>0.736871</td>
      <td>Chesapeake_Bay_retriever</td>
      <td>True</td>
      <td>0.087503</td>
      <td>meerkat</td>
      <td>False</td>
      <td>0.042058</td>
    </tr>
    <tr>
      <th>234</th>
      <td>835172783151792128</td>
      <td>Border_collie</td>
      <td>True</td>
      <td>0.663138</td>
      <td>Border_collie</td>
      <td>True</td>
      <td>0.663138</td>
      <td>collie</td>
      <td>True</td>
      <td>0.152494</td>
      <td>Cardigan</td>
      <td>True</td>
      <td>0.035471</td>
    </tr>
    <tr>
      <th>235</th>
      <td>835152434251116546</td>
      <td>American_Staffordshire_terrier</td>
      <td>True</td>
      <td>0.0127309</td>
      <td>swing</td>
      <td>False</td>
      <td>0.967066</td>
      <td>American_Staffordshire_terrier</td>
      <td>True</td>
      <td>0.012731</td>
      <td>Staffordshire_bullterrier</td>
      <td>True</td>
      <td>0.007039</td>
    </tr>
    <tr>
      <th>236</th>
      <td>834931633769889797</td>
      <td>soft-coated_wheaten_terrier</td>
      <td>True</td>
      <td>0.196476</td>
      <td>ice_bear</td>
      <td>False</td>
      <td>0.330573</td>
      <td>soft-coated_wheaten_terrier</td>
      <td>True</td>
      <td>0.196476</td>
      <td>Irish_terrier</td>
      <td>True</td>
      <td>0.073097</td>
    </tr>
    <tr>
      <th>237</th>
      <td>834786237630337024</td>
      <td>Border_terrier</td>
      <td>True</td>
      <td>0.156276</td>
      <td>Border_terrier</td>
      <td>True</td>
      <td>0.156276</td>
      <td>Norwegian_elkhound</td>
      <td>True</td>
      <td>0.125912</td>
      <td>Boston_bull</td>
      <td>True</td>
      <td>0.096624</td>
    </tr>
    <tr>
      <th>238</th>
      <td>834574053763584002</td>
      <td>golden_retriever</td>
      <td>True</td>
      <td>0.226564</td>
      <td>toilet_tissue</td>
      <td>False</td>
      <td>0.262936</td>
      <td>golden_retriever</td>
      <td>True</td>
      <td>0.226564</td>
      <td>bathtub</td>
      <td>False</td>
      <td>0.078879</td>
    </tr>
    <tr>
      <th>239</th>
      <td>834458053273591808</td>
      <td>Rhodesian_ridgeback</td>
      <td>True</td>
      <td>0.468619</td>
      <td>Rhodesian_ridgeback</td>
      <td>True</td>
      <td>0.468619</td>
      <td>whippet</td>
      <td>True</td>
      <td>0.177531</td>
      <td>redbone</td>
      <td>True</td>
      <td>0.106552</td>
    </tr>
    <tr>
      <th>240</th>
      <td>834209720923721728</td>
      <td>golden_retriever</td>
      <td>True</td>
      <td>0.754799</td>
      <td>golden_retriever</td>
      <td>True</td>
      <td>0.754799</td>
      <td>Pekinese</td>
      <td>True</td>
      <td>0.197861</td>
      <td>Labrador_retriever</td>
      <td>True</td>
      <td>0.008654</td>
    </tr>
    <tr>
      <th>241</th>
      <td>834167344700198914</td>
      <td>None</td>
      <td>False</td>
      <td>None</td>
      <td>ox</td>
      <td>False</td>
      <td>0.991682</td>
      <td>bison</td>
      <td>False</td>
      <td>0.005335</td>
      <td>water_buffalo</td>
      <td>False</td>
      <td>0.001130</td>
    </tr>
    <tr>
      <th>242</th>
      <td>834086379323871233</td>
      <td>Labrador_retriever</td>
      <td>True</td>
      <td>0.0452627</td>
      <td>bath_towel</td>
      <td>False</td>
      <td>0.736759</td>
      <td>sleeping_bag</td>
      <td>False</td>
      <td>0.062959</td>
      <td>Labrador_retriever</td>
      <td>True</td>
      <td>0.045263</td>
    </tr>
    <tr>
      <th>243</th>
      <td>833863086058651648</td>
      <td>kuvasz</td>
      <td>True</td>
      <td>0.494969</td>
      <td>kuvasz</td>
      <td>True</td>
      <td>0.494969</td>
      <td>Great_Pyrenees</td>
      <td>True</td>
      <td>0.312632</td>
      <td>golden_retriever</td>
      <td>True</td>
      <td>0.141736</td>
    </tr>
    <tr>
      <th>244</th>
      <td>833826103416520705</td>
      <td>Chihuahua</td>
      <td>True</td>
      <td>0.438054</td>
      <td>Chihuahua</td>
      <td>True</td>
      <td>0.438054</td>
      <td>kelpie</td>
      <td>True</td>
      <td>0.149706</td>
      <td>Pembroke</td>
      <td>True</td>
      <td>0.096480</td>
    </tr>
    <tr>
      <th>245</th>
      <td>833722901757046785</td>
      <td>West_Highland_white_terrier</td>
      <td>True</td>
      <td>0.918144</td>
      <td>West_Highland_white_terrier</td>
      <td>True</td>
      <td>0.918144</td>
      <td>Maltese_dog</td>
      <td>True</td>
      <td>0.025721</td>
      <td>Lakeland_terrier</td>
      <td>True</td>
      <td>0.020211</td>
    </tr>
    <tr>
      <th>246</th>
      <td>833479644947025920</td>
      <td>golden_retriever</td>
      <td>True</td>
      <td>0.727039</td>
      <td>golden_retriever</td>
      <td>True</td>
      <td>0.727039</td>
      <td>cocker_spaniel</td>
      <td>True</td>
      <td>0.071140</td>
      <td>Tibetan_mastiff</td>
      <td>True</td>
      <td>0.048694</td>
    </tr>
    <tr>
      <th>247</th>
      <td>833124694597443584</td>
      <td>Cardigan</td>
      <td>True</td>
      <td>0.710523</td>
      <td>Cardigan</td>
      <td>True</td>
      <td>0.710523</td>
      <td>kelpie</td>
      <td>True</td>
      <td>0.106102</td>
      <td>shopping_cart</td>
      <td>False</td>
      <td>0.055475</td>
    </tr>
    <tr>
      <th>248</th>
      <td>832998151111966721</td>
      <td>boxer</td>
      <td>True</td>
      <td>0.539036</td>
      <td>boxer</td>
      <td>True</td>
      <td>0.539036</td>
      <td>French_bulldog</td>
      <td>True</td>
      <td>0.317617</td>
      <td>bull_mastiff</td>
      <td>True</td>
      <td>0.093928</td>
    </tr>
    <tr>
      <th>249</th>
      <td>832757312314028032</td>
      <td>Cardigan</td>
      <td>True</td>
      <td>0.160888</td>
      <td>Cardigan</td>
      <td>True</td>
      <td>0.160888</td>
      <td>Staffordshire_bullterrier</td>
      <td>True</td>
      <td>0.159441</td>
      <td>Boston_bull</td>
      <td>True</td>
      <td>0.154368</td>
    </tr>
  </tbody>
</table>
</div>



```python
df_twitter_clean = df_twitter_clean.drop(['p1','p1_conf','p1_dog','p2','p2_conf','p2_dog','p3','p3_conf','p3_dog'],axis = 1)
```

### 测试


```python
df_twitter_clean.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 1994 entries, 0 to 1993
    Data columns (total 11 columns):
    tweet_id          1994 non-null object
    timestamp         1994 non-null datetime64[ns]
    text              1994 non-null object
    name              1994 non-null object
    retweet_count     1994 non-null float64
    favorite_count    1994 non-null float64
    status            1994 non-null object
    rating            1993 non-null float64
    p_conf            1994 non-null object
    p_dog             1994 non-null object
    p                 1994 non-null object
    dtypes: datetime64[ns](1), float64(3), object(7)
    memory usage: 266.9+ KB


### 定义
Q6_为了后续统计分析不受影响，所有缺失的数据应该被标记为np.nan的逻辑形式，而不是'None'的字符串形式

### 代码


```python
print('None' in df_twitter_clean.tweet_id.value_counts())
print('None' in df_twitter_clean.timestamp.value_counts())
print('None' in df_twitter_clean.text.value_counts())
print('None' in df_twitter_clean.name.value_counts())
print('None' in df_twitter_clean.retweet_count.value_counts())
print('None' in df_twitter_clean.favorite_count.value_counts())
print('None' in df_twitter_clean.status.value_counts())
print('None' in df_twitter_clean.rating.value_counts())
print('None' in df_twitter_clean.p_conf.value_counts())
print('None' in df_twitter_clean.p_dog.value_counts())
print('None' in df_twitter_clean.p.value_counts())
```

    False
    False
    False
    True
    False
    False
    False
    False
    True
    False
    True



```python
df_twitter_clean.name = df_twitter_clean.name.replace('None',np.nan)
df_twitter_clean.p_conf = df_twitter_clean.p_conf.replace('None',np.nan)
df_twitter_clean.p = df_twitter_clean.p.replace('None',np.nan)
```

### 测试


```python
print('None' in df_twitter_clean.tweet_id.value_counts())
print('None' in df_twitter_clean.timestamp.value_counts())
print('None' in df_twitter_clean.text.value_counts())
print('None' in df_twitter_clean.name.value_counts())
print('None' in df_twitter_clean.retweet_count.value_counts())
print('None' in df_twitter_clean.favorite_count.value_counts())
print('None' in df_twitter_clean.status.value_counts())
print('None' in df_twitter_clean.rating.value_counts())
print('None' in df_twitter_clean.p_conf.value_counts())
print('None' in df_twitter_clean.p_dog.value_counts())
print('None' in df_twitter_clean.p.value_counts())
```

    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False


## 合并数据
需要完成tweet-archive-master文档应包含以下内容，相应数据来源在括号中标识：

tweet_id 推特账号 （df_tweeter）
text 推文（df_tweeter）
timestamp 时间戳（df_tweeter）
retweet_count 转推数（df_json）
favorite_count 喜爱数 （df_json）
rating 评分（df_tweeter）
name 狗名（df_tweeter）
status 狗的地位（df_tweeter）
p 狗的品种(df_pred)
p_conf 品种预测的概率(df_pred)


```python
df_twitter_clean.to_csv('twitter_archive_master.csv', index=False)
```

# 数据分析
包含内容：
* 评分高低应该和转发数量/喜爱程度存在关系
* 评分高低和狗的种类存在关系
* 评分高低和狗的地位存在关系
* 评论的词云分析(无法导入wordcloud模块）
* 各种评分的箱形分布图
* 评分的总体分布情况


```python
#sns.set()
df_twitter_drop = df_twitter_clean.dropna(axis=0)
df_twitter_drop.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 1229 entries, 1 to 1963
    Data columns (total 11 columns):
    tweet_id          1229 non-null object
    timestamp         1229 non-null datetime64[ns]
    text              1229 non-null object
    name              1229 non-null object
    retweet_count     1229 non-null float64
    favorite_count    1229 non-null float64
    status            1229 non-null object
    rating            1229 non-null float64
    p_conf            1229 non-null float64
    p_dog             1229 non-null object
    p                 1229 non-null object
    dtypes: datetime64[ns](1), float64(4), object(6)
    memory usage: 115.2+ KB


## 结论1：喜爱数与转发数成正相关关系

* 1-1评分数与转发数大体成正相关关系 相关系数R-squared达到0.855
* 1-2大约30%标识喜欢的读者，会转发一次推文


```python
#favorite_count & retweet_count之间关系
f_and_r = sns.jointplot('favorite_count','retweet_count', data = df_twitter_drop,kind = "reg",size = 8)
mod = smf.ols(formula='retweet_count ~ favorite_count', data=df_twitter_drop)
res = mod.fit()
print(res.summary())
#f_and_r = f_and_r.plot(sns.regplot, sns.distplot)
#f_and_r = f_and_r.annotate(f_and_r.pearsonr,rsquare)
#https://blog.csdn.net/ice_martin/article/details/61617053
#http://seaborn.pydata.org/index.html
```

                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:          retweet_count   R-squared:                       0.855
    Model:                            OLS   Adj. R-squared:                  0.855
    Method:                 Least Squares   F-statistic:                     7241.
    Date:                Tue, 03 Apr 2018   Prob (F-statistic):               0.00
    Time:                        13:40:54   Log-Likelihood:                -10785.
    No. Observations:                1229   AIC:                         2.157e+04
    Df Residuals:                    1227   BIC:                         2.158e+04
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ==================================================================================
                         coef    std err          t      P>|t|      [0.025      0.975]
    ----------------------------------------------------------------------------------
    Intercept       -224.8620     56.971     -3.947      0.000    -336.633    -113.091
    favorite_count     0.3138      0.004     85.092      0.000       0.307       0.321
    ==============================================================================
    Omnibus:                     1194.006   Durbin-Watson:                   1.364
    Prob(Omnibus):                  0.000   Jarque-Bera (JB):           147714.683
    Skew:                           4.140   Prob(JB):                         0.00
    Kurtosis:                      56.066   Cond. No.                     1.97e+04
    ==============================================================================
    
    Warnings:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
    [2] The condition number is large, 1.97e+04. This might indicate that there are
    strong multicollinearity or other numerical problems.



![png](output_111_1.png)


## 结论2： 最受欢迎的狗狗名字
* 2-1 Tucker、Lucy、Charlie、Cooper、Penny、Oliver是起的最多的Top5名字。


```python
#哪些是大家常取的名字
sns.set(style='whitegrid')
sns_named = pd.DataFrame(df_twitter_drop.name.value_counts().sort_values().tail(15))
sns_named.plot(kind='barh',figsize = (8,8))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f3bfbba06d8>




![png](output_113_1.png)


## 结论3：哪些品种最受欢迎
* 3-1 Chihuahua作为最受欢迎的品种位列评论数第一，但是其评分比较分散，喜欢的人很喜欢，不喜欢的人也很不喜欢，以至于其得分均值并不高
* 3-2 French Bulldog（法国斗牛犬）是评分均值最高的品种
* 3-3 可以看到总体上讲养的越多的品种得分越趋向于较高得分


```python
sns_p = pd.DataFrame(df_twitter_drop.p.value_counts().sort_values().tail(15))
df_p = df_twitter_drop[df_twitter_drop.p.isin(sns_p.index)]
plt.subplots(figsize=(8, 8))
sns.boxplot(x='rating',y='p',data = df_p)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f3bfbca2550>




![png](output_115_1.png)



```python
sns_p_2 = pd.DataFrame(df_twitter_drop.p.value_counts().sort_values().head(20))
df_p_2 = df_twitter_drop[df_twitter_drop.p.isin(sns_p_2.index)]
plt.subplots(figsize=(8, 8))
sns.boxplot(x='rating',y='p',data = df_p_2)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f3bfb59d390>




![png](output_116_1.png)


## 结论4：
* 4-1 大多数人的评分都集中在1.0~1.2之间。
* 4-2 整体的评分分布是左偏的，评分均值偏高的方向，大家对于狗狗的评分都趋向打高分


```python
plt.subplots(figsize=(8, 8))
sns_rating = sns.distplot(df_twitter_drop.rating,hist=True,)
```


![png](output_118_0.png)


## 结论5：
* 5-1 doggo是最受欢迎的狗的地位
* 5-2 pupper是最不受欢迎的狗的地位
* 5-3 而以上两种狗的地位的评分分布都非常的分散


```python
sns_status = pd.DataFrame(df_twitter_drop.status.value_counts().sort_values().head(4))
df_status = df_twitter_drop[df_twitter_drop.status.isin(sns_status.index)]
sns.set(style='whitegrid')
plt.subplots(figsize=(8, 8))
sns.boxplot(x='rating',y='status',data = df_status)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f3bf87ae0b8>




![png](output_120_1.png)

